package com.example.thewallet.search_fragments

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.view.isVisible
import androidx.navigation.fragment.findNavController
import com.example.thewallet.R
import com.example.thewallet.activitys.LoginA
import com.example.thewallet.activitys.MainActivity
import com.example.thewallet.adapters.ExpenseAdapter
import kotlinx.android.synthetic.main.fragment_search_expense.view.et_Search_name_exp_search
import kotlinx.android.synthetic.main.fragment_search_expense.view.et_Section_filter_name_Exp
import kotlinx.android.synthetic.main.fragment_search_expense.view.imageForShowFilter
import kotlinx.android.synthetic.main.fragment_search_expense.view.liner3_search
import kotlinx.android.synthetic.main.fragment_search_expense.view.listView_in_SearcExp
import kotlinx.android.synthetic.main.fragment_search_expense.view.nodataLottie_search_exp
import kotlinx.android.synthetic.main.fragment_search_expense.view.spinnerForSectionFilter
import kotlinx.android.synthetic.main.fragment_view_exp_and_edit.view.iv_backFromView_edit_Exp
import kotlinx.android.synthetic.main.fragment_view_exp_and_edit.view.liner3
import kotlinx.android.synthetic.main.fragment_view_exp_and_edit.view.listView_in_ViewAndEditExpScreen
import kotlinx.android.synthetic.main.fragment_view_exp_and_edit.view.nodataLottie_viewexp
import kotlinx.android.synthetic.main.fragment_view_exp_and_edit.view.tv_viewAndEditExp
import kotlinx.android.synthetic.main.sectio_name_array.view.btn_cancel_setion_names_dialog
import kotlinx.android.synthetic.main.sectio_name_array.view.et_Search_sectioName_dialog
import kotlinx.android.synthetic.main.sectio_name_array.view.list_forSectiosNames_dialog

class SearchExpense : Fragment() {


    private val action=R.id.action_statisticsFragment_to_editExp
    private val back=R.id.statisticsFragment

    @SuppressLint("ResourceAsColor")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val inf=inflater.inflate(R.layout.fragment_search_expense, container, false)
        try {
            if (LoginA.db.getExpensesCount()>0L){
                inf.liner3_search.visibility=View.VISIBLE
                inf.nodataLottie_search_exp.visibility=View.GONE
                inf.imageForShowFilter.isEnabled=true
                inf.liner3_search.setBackgroundColor(R.color.Dark)
            }else{
                inf.imageForShowFilter.isEnabled=false
            }


            val textWatche = object : TextWatcher {
                override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                }
                override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                }

                override fun afterTextChanged(p0: Editable?) {
                    val section_name = inf.et_Section_filter_name_Exp.text.toString()
                    if (section_name.isEmpty()){
                        inf.listView_in_SearcExp.adapter = ExpenseAdapter(requireContext()
                            , LoginA.db.getAllExpenses(), this@SearchExpense,action,back,inf.nodataLottie_search_exp,  inf.liner3_search,inf.imageForShowFilter)
                    }else if (section_name==resources.getString(R.string.all)) {
                        inf.listView_in_SearcExp.adapter = ExpenseAdapter(requireContext(),
                            LoginA.db.getAllExpenses(), this@SearchExpense,action,back,inf.nodataLottie_search_exp,  inf.liner3_search,inf.imageForShowFilter)
                    }else {
                        inf.listView_in_SearcExp.adapter = ExpenseAdapter(requireContext()
                            , LoginA.db.getExpenseOnSection(section_name), this@SearchExpense,action,back,inf.nodataLottie_search_exp,  inf.liner3_search,inf.imageForShowFilter)
                    }
                }
            }

            inf.et_Section_filter_name_Exp.addTextChangedListener(textWatche)

            inf.et_Section_filter_name_Exp.setOnClickListener {
                showSectionDialog(inf)
            }
            var flag=0
            inf.imageForShowFilter.setOnClickListener {
                if (flag==0) {
                    inf.imageForShowFilter.setImageResource(R.drawable.baseline_filter_list_off_24)
                    inf.spinnerForSectionFilter.visibility = View.VISIBLE
                    flag = 1
                }else if (flag==1){
                    inf.imageForShowFilter.setImageResource(R.drawable.baseline_filter_list_24)
                    inf.spinnerForSectionFilter.visibility = View.GONE
                    inf.et_Section_filter_name_Exp.text?.clear()

                    flag=0
                }
            }


            inf.listView_in_SearcExp.adapter = ExpenseAdapter(requireContext(), LoginA.db.getAllExpenses(),this,action,back,inf.nodataLottie_search_exp,  inf.liner3_search,inf.imageForShowFilter)

            val textWatcher = object : TextWatcher {
                override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                }

                override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                    try {
                        if ( inf.spinnerForSectionFilter.isVisible&&inf.et_Section_filter_name_Exp.text!=null) {
                            if (inf.et_Section_filter_name_Exp.text.toString()!=resources.getString(R.string.all)) {
                                val filter = LoginA.db.searchForExpNameWithSectionId(
                                    inf.et_Section_filter_name_Exp.text.toString(),
                                    p0.toString()
                                )
                                inf.listView_in_SearcExp.adapter =
                                    ExpenseAdapter(requireContext(), filter, this@SearchExpense,action,back,inf.nodataLottie_search_exp,  inf.liner3_search,inf.imageForShowFilter)
                            }else{
                                inf.listView_in_SearcExp.adapter =
                                    ExpenseAdapter(requireContext(),
                                        LoginA.db.searchForExpNameWithOutSectionId(p0.toString()), this@SearchExpense,action,back,inf.nodataLottie_search_exp,  inf.liner3_search,inf.imageForShowFilter)
                            }
                        }else{
                            val filter = LoginA.db.searchForExpNameWithOutSectionId(p0.toString())
                            inf.listView_in_SearcExp.adapter =
                                ExpenseAdapter(requireContext(), filter, this@SearchExpense,action,back,inf.nodataLottie_search_exp,  inf.liner3_search,inf.imageForShowFilter)
                        }
                    }catch (e:Exception){
                        Toast.makeText(requireContext(), e.message, Toast.LENGTH_SHORT).show()
                    }
                }

                override fun afterTextChanged(p0: Editable?) {
                }
            }
            inf.et_Search_name_exp_search.addTextChangedListener(textWatcher)

        }catch (e:Exception){
            Toast.makeText(requireContext(), e.message, Toast.LENGTH_LONG).show()}
        return inf
    }

    private fun showSectionDialog(inf:View) {
        val view = LayoutInflater.from(requireContext()).inflate(R.layout.sectio_name_array, null)
        val alertDialog = AlertDialog.Builder(requireContext(), R.style.CustomAlertDialog).create()
        alertDialog.setCanceledOnTouchOutside(false)
        alertDialog.setView(view)
        view.list_forSectiosNames_dialog.setOnItemClickListener { parent, view, position, id ->
            val name = parent.getItemAtPosition(position)
            inf.et_Section_filter_name_Exp.setText(name.toString())
            alertDialog.dismiss()
        }

        val textWatcher = object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                try {
                    val filter = LoginA.db.searchForSectionsNameJustName(p0.toString())
                    filter.add(0, resources.getString(R.string.all))
                    view.list_forSectiosNames_dialog.adapter =
                        ArrayAdapter(requireContext(), R.layout.dropmenu, filter)

                }catch (e:Exception){
                    Toast.makeText(requireContext(), e.message, Toast.LENGTH_SHORT).show()
                }
            }

            override fun afterTextChanged(p0: Editable?) {
            }
        }
        view.et_Search_sectioName_dialog.addTextChangedListener(textWatcher)
        val array= LoginA.db.getSectionsName()
        array.add(0,resources.getString(R.string.all))
        view.list_forSectiosNames_dialog.adapter = ArrayAdapter(requireContext(),  R.layout.dropmenu,array )
        view.btn_cancel_setion_names_dialog.setOnClickListener {
            alertDialog.dismiss()
        }
        alertDialog.show()
    }

}