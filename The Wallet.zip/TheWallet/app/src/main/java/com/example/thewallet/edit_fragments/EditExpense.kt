package com.example.thewallet.edit_fragments

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.navigation.fragment.findNavController
import com.example.thewallet.luxuries.EXP_DAY
import com.example.thewallet.luxuries.EXP_DES
import com.example.thewallet.luxuries.EXP_ID
import com.example.thewallet.luxuries.EXP_MONTH
import com.example.thewallet.luxuries.EXP_NAME
import com.example.thewallet.luxuries.EXP_PRICE
import com.example.thewallet.luxuries.EXP_SECTION_NAME
import com.example.thewallet.luxuries.EXP_YEAR
import com.example.thewallet.activitys.LoginA
import com.example.thewallet.R
import com.example.thewallet.activitys.MainActivity
import com.example.thewallet.dataclasss.DoMath
import com.example.thewallet.luxuries.EXP_BACK
import com.example.thewallet.luxuries.ForDataCurrency
import com.example.thewallet.luxuries.currency_key
import com.example.thewallet.luxuries.shared_settings_file_name
import com.example.thewallet.luxuries.shared_wallet_balance
import com.example.thewallet.luxuries.shared_wallet_expenses
import com.example.thewallet.luxuries.shared_wallet_file_name
import kotlinx.android.synthetic.main.fragment_edit_exp.view.btn_save_EditExp
import kotlinx.android.synthetic.main.fragment_edit_exp.view.currencyEditExp
import kotlinx.android.synthetic.main.fragment_edit_exp.view.et_Edit_Expense_description
import kotlinx.android.synthetic.main.fragment_edit_exp.view.et_Edit_Expense_name
import kotlinx.android.synthetic.main.fragment_edit_exp.view.et_Edit_Expense_price
import kotlinx.android.synthetic.main.fragment_edit_exp.view.et_Edit_Section_name_Exp
import kotlinx.android.synthetic.main.fragment_edit_exp.view.et_Edit_date_picker
import kotlinx.android.synthetic.main.fragment_edit_exp.view.iv_backFromEditExp
import kotlinx.android.synthetic.main.fragment_edit_exp.view.tv_EditExp
import kotlinx.android.synthetic.main.fragment_edit_exp.view.tv_walletBalanceEditExp
import kotlinx.android.synthetic.main.sectio_name_array.view.btn_cancel_setion_names_dialog
import kotlinx.android.synthetic.main.sectio_name_array.view.et_Search_sectioName_dialog
import kotlinx.android.synthetic.main.sectio_name_array.view.list_forSectiosNames_dialog
import java.util.Calendar


class EditExpense : Fragment() {

    private var param_id: String? = null
    private var param_name: String? = null
    private var param_description: String? = null
    private var param_price: Float? = null
    private var param_section_name: String? = null
    private var param_day: Int? = null
    private var param_month: Int? = null
    private var param_year: Int? = null
    private var param_back: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param_id = it.getString(EXP_ID)
            param_name = it.getString(EXP_NAME)
            param_description = it.getString(EXP_DES)
            param_price = it.getFloat(EXP_PRICE)
            param_section_name = it.getString(EXP_SECTION_NAME)
            param_day = it.getInt(EXP_DAY)
            param_month = it.getInt(EXP_MONTH)
            param_year = it.getInt(EXP_YEAR)
            param_back = it.getInt(EXP_BACK)
        }
    }

    @SuppressLint("SetTextI18n")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        val inf=inflater.inflate(R.layout.fragment_edit_exp, container, false)

        when (this.resources.configuration?.uiMode?.and(Configuration.UI_MODE_NIGHT_MASK)) {
            Configuration.UI_MODE_NIGHT_YES -> {
                inf.tv_EditExp.setTextColor(Color.WHITE)
                inf.et_Edit_Expense_name.setTextColor(Color.WHITE)
                inf.et_Edit_Expense_description.setTextColor(Color.WHITE)
                inf.et_Edit_Expense_price.setTextColor(Color.WHITE)
                inf.et_Edit_date_picker.setTextColor(Color.WHITE)
                inf.et_Edit_Section_name_Exp.setTextColor(Color.WHITE)

            }

            Configuration.UI_MODE_NIGHT_NO -> {
                inf.tv_EditExp.setTextColor(Color.BLACK)
                inf.et_Edit_Expense_name.setTextColor(Color.BLACK)
                inf.et_Edit_Expense_description.setTextColor(Color.BLACK)
                inf.et_Edit_Expense_price.setTextColor(Color.BLACK)
                inf.et_Edit_date_picker.setTextColor(Color.BLACK)
                inf.et_Edit_Section_name_Exp.setTextColor(Color.BLACK)

            }

        }

        inf.iv_backFromEditExp.setOnClickListener {
            findNavController().popBackStack(param_back!!,false)
        }
        val sharedPreferences=requireContext().getSharedPreferences(shared_wallet_file_name, Context.MODE_PRIVATE)
        val shared2=requireContext().getSharedPreferences(shared_settings_file_name, Context.MODE_PRIVATE)
        val currency=shared2.getInt(currency_key,0)
        inf.currencyEditExp.text = ForDataCurrency[currency]

        val showBalance= sharedPreferences.getFloat(shared_wallet_balance,0f)
        inf.tv_walletBalanceEditExp.text = "$showBalance"
        inf.et_Edit_Expense_name.setText(param_name)
        inf.et_Edit_Expense_description.setText(param_description)
        inf.et_Edit_Expense_price.setText(param_price.toString())
        inf.et_Edit_date_picker.setText("${param_day}-${param_month}-${param_year}")
        inf.et_Edit_Section_name_Exp.setText(param_section_name)


        inf.et_Edit_Section_name_Exp.setOnClickListener {
            try {
                showSectionDialog(inf)

            } catch (e: Exception) {
                Toast.makeText(requireContext(), e.message, Toast.LENGTH_SHORT).show()
            }
        }

        inf.btn_save_EditExp.setOnClickListener {
            val balance= sharedPreferences.getFloat(shared_wallet_balance,0f)
            val oldExpenses= sharedPreferences.getFloat(shared_wallet_expenses,0f)
            val name = inf.et_Edit_Expense_name.text.toString().trim()
            val description = inf.et_Edit_Expense_description.text.toString().trim()
            val price = inf.et_Edit_Expense_price.text.toString().trim()
            val section_name = inf.et_Edit_Section_name_Exp.text.toString().trim()
            if (name.isNotEmpty() && description.isNotEmpty() && price.isNotEmpty()
                && section_name.isNotEmpty()&& param_day !=null&& param_month !=null&& param_year !=null) {

                val newPrice= doMath(price.toFloat())
                if (newPrice.state=="big"){
                    if (canAddExpense(balance,newPrice.price)) {
                        val result = LoginA.db.updateExpense(
                            param_id.toString(),
                            name,
                            description,
                            param_day!!,
                            param_month!!,
                            param_year!!,
                            price.toFloat(),
                            section_name
                        )

                        if (result) {
                            val newBalance=balance-newPrice.price
                            val newExpenses=oldExpenses+newPrice.price
                            param_price=price.toFloat()
                            sharedPreferences.edit().putFloat(shared_wallet_balance,newBalance).apply()
                            sharedPreferences.edit().putFloat(shared_wallet_expenses,newExpenses).apply()
                            inf.tv_walletBalanceEditExp.text = "$newBalance"
                            Toast.makeText(
                                requireContext(),
                                resources.getString(R.string.toastEdit),
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            Toast.makeText(
                                requireContext(),
                                resources.getString(R.string.toastFiledEdit),
                                Toast.LENGTH_SHORT
                            ).show()
                        }

                    }else{
                        Toast.makeText(requireContext(), resources.getString(R.string.toasNoBalanceForthisEdit), Toast.LENGTH_LONG).show()
                        inf.et_Edit_Expense_price.setText(param_price.toString())
                    }
                }else if (newPrice.state=="small"){
                        val result = LoginA.db.updateExpense(
                            param_id.toString(),
                            name,
                            description,
                            param_day!!,
                            param_month!!,
                            param_year!!,
                            price.toFloat(),
                            section_name
                        )

                        if (result) {
                            val newBalance=balance+newPrice.price
                            val newExpenses=oldExpenses-newPrice.price
                            param_price=price.toFloat()
                            sharedPreferences.edit().putFloat(shared_wallet_balance,newBalance).apply()
                            sharedPreferences.edit().putFloat(shared_wallet_expenses,newExpenses).apply()
                            inf.tv_walletBalanceEditExp.text = "$newBalance"
                            Toast.makeText(
                                requireContext(),
                                resources.getString(R.string.toastEdit),
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            Toast.makeText(
                                requireContext(),
                                resources.getString(R.string.toastFiledEdit),
                                Toast.LENGTH_SHORT
                            ).show()
                        }


                }else{
                    if (canAddExpense(balance,newPrice.price)) {
                        val result = LoginA.db.updateExpense(
                            param_id.toString(),
                            name,
                            description,
                            param_day!!,
                            param_month!!,
                            param_year!!,
                            param_price!!,
                            section_name
                        )

                        if (result) {
                            Toast.makeText(
                                requireContext(),
                                resources.getString(R.string.toastEdit),
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            Toast.makeText(
                                requireContext(),
                                resources.getString(R.string.toastFiledEdit),
                                Toast.LENGTH_SHORT
                            ).show()
                        }

                    }else{
                        Toast.makeText(requireContext(), resources.getString(R.string.toasNoBalanceForthisEdit), Toast.LENGTH_LONG).show()
                        inf.et_Edit_Expense_price.setText(param_price.toString())
                    }
                }


            }else{
                Toast.makeText(requireContext(), resources.getString(R.string.fillet), Toast.LENGTH_SHORT).show()
            }
        }


        val c = Calendar.getInstance()
        val year = c.get(Calendar.YEAR)
        val month = c.get(Calendar.MONTH)
        val day = c.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(requireContext(), { view, year, monthOfYear, dayOfMonth ->
                try {

                   param_day = dayOfMonth
                   param_month = monthOfYear + 1
                    param_year = year
                    inf.et_Edit_date_picker.setText("${param_day}-${param_month}-${param_year}")
                } catch (e: Exception) {
                    Toast.makeText(requireContext(), e.message, Toast.LENGTH_SHORT).show()
                }
            }, year, month, day)


        inf.et_Edit_date_picker.setOnClickListener {
            datePickerDialog.show()
        }

    return inf
}



    private fun canAddExpense(balance:Float,newExpense: Float): Boolean {
    val math=balance-newExpense
    return math>=0f
}

private fun showSectionDialog(inf:View) {
    val view = LayoutInflater.from(requireContext()).inflate(R.layout.sectio_name_array, null)
    val alertDialog = AlertDialog.Builder(requireContext(), R.style.CustomAlertDialog).create()
    alertDialog.setCanceledOnTouchOutside(false)
    alertDialog.setView(view)
    view.list_forSectiosNames_dialog.setOnItemClickListener { parent, view, position, id ->
        val name = parent.getItemAtPosition(position)
        inf.et_Edit_Section_name_Exp.setText(name.toString())
        alertDialog.dismiss()
    }

    val textWatcher = object : TextWatcher {
        override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
        }

        override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            try {
                val filter = LoginA.db.searchForSectionsTitle(p0.toString())
                view.list_forSectiosNames_dialog.adapter = ArrayAdapter(requireContext(), R.layout.dropmenu, filter)

            }catch (e:Exception){
                Toast.makeText(requireContext(), e.message, Toast.LENGTH_SHORT).show()
            }
        }

        override fun afterTextChanged(p0: Editable?) {
        }
    }
    view.et_Search_sectioName_dialog.addTextChangedListener(textWatcher)

    view.list_forSectiosNames_dialog.adapter = ArrayAdapter(requireContext(),  R.layout.dropmenu, LoginA.db.getSectionsName())
    view.btn_cancel_setion_names_dialog.setOnClickListener {
        alertDialog.dismiss()
    }
    alertDialog.show()
}

    fun doMath(newPrice:Float): DoMath {
        val price:Float?
        if (param_price!! < newPrice){
            price=newPrice-param_price!!
            return DoMath("big",price)

        }else if (param_price!!>newPrice){
            price=param_price!!-newPrice
            return DoMath("small",price)
        }
        return DoMath("equal",0.0f)
    }
    override fun onAttach(context: Context) {
        (activity as MainActivity).hideBottomNavigation()
        super.onAttach(context)
    }

    override fun onDetach() {
        super.onDetach()
        (activity as MainActivity).showBottomNavigation()
    }
}
