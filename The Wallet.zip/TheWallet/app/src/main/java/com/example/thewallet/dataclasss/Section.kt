package com.example.thewallet.dataclasss


data class Section(val name:String,val description: String)
