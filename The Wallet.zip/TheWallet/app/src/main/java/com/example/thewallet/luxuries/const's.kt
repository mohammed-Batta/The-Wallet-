package com.example.thewallet.luxuries

// arguments key for Edit Expense Fragment
const val EXP_ID = "id"
const val EXP_NAME = "name"
const val EXP_DES = "description"
const val EXP_PRICE = "price"
const val EXP_SECTION_NAME = "sectionname"
const val EXP_DAY = "day"
const val EXP_MONTH = "month"
const val EXP_YEAR = "year"
const val EXP_BACK = "back"

// Currency Shared
val arrayCurrency = arrayOf("Dollar - $","Euro - €","Pound Sterling – £","Yen – ¥","Sheqel – ₪","Dinar – د.ك","Dirham – د.إ","Riyal – ﷼")
val ForDataCurrency = arrayOf("$","€","£","¥","₪","د.ك","د.إ","﷼")
val currency_key ="currency"




// arguments key for Edit Section's Fragment
const val SEC_NAME = "name"
const val SEC_DES = "description"
const val SEC_BACK = "back"

// sharedPreferences file's name
const val shared_settings_file_name="my_settings"
const val shared_wallet_file_name="TheWallet"


//  sharedPreferences Wallet key's
const val shared_wallet_balance="balance"
const val shared_wallet_additions="additions"
const val shared_wallet_expenses="expenses"




// sharedPreferences Biometric's key
const val shared_settings_Biometrics_key="Biometrics"
const val shared_settings_Biometrics_disabled="disabled"
const val shared_settings_Biometrics_enabled="enabled"

// PersonalDetails key
const val shared_settings_PersonalDetails_name="name"
const val shared_settings_PersonalDetails_image="image.txt"


// sharedPreferences LockScreen key's
const val shared_settings_LockScreen_password="password"
const val shared_settings_LockScreen_privateQ="privateQ"
const val shared_settings_LockScreen_answer="answer"

// sharedPreferences language key's
const val shared_settings_language_key="language"
const val shared_settings_language_en= "en"
const val shared_settings_language_ar= "ar"

// sharedPreferences mode key's
const val shared_settings_mode_dark= "dark"
const val shared_settings_mode_light= "light"
const val shared_settings_mode_key= "mode"







