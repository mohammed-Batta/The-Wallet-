package com.example.thewallet.dataclasss

data class DoMath(val state:String,val price:Float)