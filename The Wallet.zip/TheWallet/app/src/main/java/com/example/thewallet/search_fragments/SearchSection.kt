package com.example.thewallet.search_fragments

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.example.thewallet.R
import com.example.thewallet.activitys.LoginA
import com.example.thewallet.activitys.LoginA.Companion.db
import com.example.thewallet.activitys.MainActivity
import com.example.thewallet.adapters.SectionAdapter
import kotlinx.android.synthetic.main.fragment_search_section.view.et_Search_name_Sec_search
import kotlinx.android.synthetic.main.fragment_search_section.view.liner2_section_search
import kotlinx.android.synthetic.main.fragment_search_section.view.listView_in_section_search
import kotlinx.android.synthetic.main.fragment_search_section.view.nodataLottie
import kotlinx.android.synthetic.main.fragment_view_section.view.tv_viewAndEditSec

class SearchSection : Fragment() {


    @SuppressLint("ResourceAsColor")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        val inf=inflater.inflate(R.layout.fragment_search_section, container, false)
        try {
            if (db.getSectionsCount()>0L){
                inf.liner2_section_search.visibility=View.VISIBLE
                inf.nodataLottie.visibility=View.GONE
                inf.liner2_section_search.setBackgroundColor(R.color.Dark)
            }

            inf.listView_in_section_search.adapter = SectionAdapter(requireContext(), db.getAllSections(),
                this,inf.nodataLottie,inf.liner2_section_search,R.id.action_statisticsFragment_to_editSection,R.id.statisticsFragment)

            val textWatcher = object : TextWatcher {
                override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                }

                override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                    try {
                        val filter = db.searchForSectionsAny(p0.toString())
                        inf.listView_in_section_search.adapter = SectionAdapter(requireContext(), filter,
                            this@SearchSection,inf.nodataLottie,inf.liner2_section_search,R.id.action_statisticsFragment_to_editSection,R.id.statisticsFragment)
                    }catch (e:Exception){
                        Toast.makeText(requireContext(), e.message, Toast.LENGTH_SHORT).show()
                    }
                }

                override fun afterTextChanged(p0: Editable?) {
                }
            }
            inf.et_Search_name_Sec_search.addTextChangedListener(textWatcher)

        }catch (e:Exception){
            Toast.makeText(requireContext(), e.message, Toast.LENGTH_LONG).show()}

        return inf
    }

}