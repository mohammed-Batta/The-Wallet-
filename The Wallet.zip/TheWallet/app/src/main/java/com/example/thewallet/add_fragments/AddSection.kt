package com.example.thewallet.add_fragments

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.example.thewallet.activitys.LoginA.Companion.db
import com.example.thewallet.R
import com.example.thewallet.activitys.MainActivity
import kotlinx.android.synthetic.main.fragment_add_sec.view.btn_save_AddSec
import kotlinx.android.synthetic.main.fragment_add_sec.view.et_Section_description
import kotlinx.android.synthetic.main.fragment_add_sec.view.et_Section_name
import kotlinx.android.synthetic.main.fragment_add_sec.view.iv_backFromAddSec
import kotlinx.android.synthetic.main.fragment_add_sec.view.tv_AddSec

class AddSection : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        val inf=inflater.inflate(R.layout.fragment_add_sec, container, false)

        when (this.resources.configuration?.uiMode?.and(Configuration.UI_MODE_NIGHT_MASK)) {
            Configuration.UI_MODE_NIGHT_YES -> {
                inf.tv_AddSec.setTextColor(Color.WHITE)
                inf.et_Section_description.setTextColor(Color.WHITE)
                inf.et_Section_name.setTextColor(Color.WHITE)
            }

            Configuration.UI_MODE_NIGHT_NO -> {
                inf.tv_AddSec.setTextColor(Color.BLACK)
                inf.et_Section_description.setTextColor(Color.BLACK)
                inf.et_Section_name.setTextColor(Color.BLACK)

            }

        }
        inf.btn_save_AddSec.setOnClickListener {
            val name=inf.et_Section_name.text.toString().trim()
            val description=inf.et_Section_description.text.toString().trim()
            if (name.isNotEmpty()&&description.isNotEmpty()){
                val result = db.addSections(name, description)
                if (result) {
                    Toast.makeText(requireContext(), resources.getString(R.string.toastAddSec), Toast.LENGTH_LONG).show()
                    inf.et_Section_name.text!!.clear()
                    inf.et_Section_description.text!!.clear()
                }else{
                Toast.makeText(requireContext(), resources.getString(R.string.toastTheNameIsSame), Toast.LENGTH_LONG).show()
                }


            }else{
                Toast.makeText(requireContext(), resources.getString(R.string.fillet), Toast.LENGTH_LONG).show()
            }
        }
        inf.iv_backFromAddSec.setOnClickListener {
            findNavController().popBackStack(R.id.homeFragment, false)
        }

        return inf
    }
    override fun onAttach(context: Context) {
        (activity as MainActivity).hideBottomNavigation()
        super.onAttach(context)
    }

    override fun onDetach() {
        super.onDetach()
        (activity as MainActivity).showBottomNavigation()
    }

}