package com.example.thewallet.adapters

import android.annotation.SuppressLint
import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.navOptions
import com.example.thewallet.R
import com.example.thewallet.activitys.LoginA.Companion.db
import com.example.thewallet.dataclasss.Section
import com.example.thewallet.luxuries.shared_wallet_balance
import com.example.thewallet.luxuries.shared_wallet_expenses
import com.example.thewallet.luxuries.shared_wallet_file_name
import com.example.thewallet.view_fragments.ViewSection.Companion.bundleSection
import kotlinx.android.synthetic.main.delete_sec_dialog.view.btn_cancel_delete_Sec_Exp_with_two_options_dialog
import kotlinx.android.synthetic.main.delete_sec_dialog.view.btn_cancel_delete_Sec_dialog
import kotlinx.android.synthetic.main.delete_sec_dialog.view.btn_cancel_delete_Sec_with_two_options_dialog
import kotlinx.android.synthetic.main.delete_sec_dialog.view.btn_done_delete_Sec_Exp_with_two_options_dialog
import kotlinx.android.synthetic.main.delete_sec_dialog.view.btn_done_delete_Sec_dialog
import kotlinx.android.synthetic.main.delete_sec_dialog.view.btn_done_delete_Sec_with_two_options_dialog
import kotlinx.android.synthetic.main.delete_sec_dialog.view.delete_the_expenseAndSec_and_return_the_amount_to_the_wallet
import kotlinx.android.synthetic.main.delete_sec_dialog.view.delete_the_expenseAndSec_without_returning_the_amount_to_the_wallet
import kotlinx.android.synthetic.main.delete_sec_dialog.view.linearLayout2Sec
import kotlinx.android.synthetic.main.delete_sec_dialog.view.linearLayoutSec
import kotlinx.android.synthetic.main.delete_sec_dialog.view.delete_the_section_but_move_its_data_to_another_section
import kotlinx.android.synthetic.main.delete_sec_dialog.view.delete_the_section_without_moving_its_data_to_another_section
import kotlinx.android.synthetic.main.delete_sec_dialog.view.linearLayout2SecForExp
import kotlinx.android.synthetic.main.delete_sec_dialog.view.radioGroupSec
import kotlinx.android.synthetic.main.delete_sec_dialog.view.radioGroupSecForExp
import kotlinx.android.synthetic.main.delete_sec_dialog.view.tv_areYouSureSec
import kotlinx.android.synthetic.main.fragment_search_section.nodataLottie
import kotlinx.android.synthetic.main.fragment_search_section.view.et_Search_name_Sec_search
import kotlinx.android.synthetic.main.fragment_search_section.view.liner2_section_search
import kotlinx.android.synthetic.main.fragment_search_section.view.nodataLottie
import kotlinx.android.synthetic.main.sec_item.view.Sec_description
import kotlinx.android.synthetic.main.sec_item.view.Sec_title
import kotlinx.android.synthetic.main.sec_item.view.sec_btn_delete
import kotlinx.android.synthetic.main.sec_item.view.sec_btn_edit
import kotlinx.android.synthetic.main.sectio_name_array.view.btn_cancel_setion_names_dialog
import kotlinx.android.synthetic.main.sectio_name_array.view.list_forSectiosNames_dialog

class SectionAdapter (private val c: Context, private val arrayList: ArrayList<Section>,
                      private val fragment: Fragment,private val lottie:View,private val card:View,private val action:Int,private val back:Int):
    ArrayAdapter<Section>(c, android.R.layout.simple_dropdown_item_1line,arrayList) {

    @SuppressLint("ViewHolder", "InflateParams")
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {

        val inf= LayoutInflater.from(c).inflate(R.layout.sec_item, null)
        inf.Sec_title.text = arrayList[position].name
        inf.Sec_description.text = arrayList[position].description

        inf.sec_btn_delete.setOnClickListener {
            showDeleteDialog(position)
        }
        inf.sec_btn_edit.setOnClickListener {
            val arguments=bundleSection(
                arrayList[position].name,
                arrayList[position].description,back).arguments

            fragment.findNavController().navigate(action,arguments,
                navOptions {
                    anim {
                        enter = android.R.animator.fade_in
                        exit = android.R.animator.fade_out } })
        }



        return inf
    }

    private fun showDeleteDialog(position: Int) {
        val view = LayoutInflater.from(c).inflate(R.layout.delete_sec_dialog, null)
        val alertDialog = AlertDialog.Builder(c, R.style.CustomAlertDialog).create()
        alertDialog.setCanceledOnTouchOutside(false)
        alertDialog.setView(view)
        view.btn_done_delete_Sec_dialog.setOnClickListener {
            if (db.getExpenseOnSection(arrayList[position].name).isNotEmpty()) {
                view.tv_areYouSureSec.visibility = View.GONE
                view.linearLayoutSec.visibility = View.GONE
                view.radioGroupSec.visibility = View.VISIBLE
                view.linearLayout2Sec.visibility = View.VISIBLE
            }else{
                val delete=db.clearSection(arrayList[position].name)
                if (delete){
                    Toast.makeText(c, c.resources.getString(R.string.toastDeleteSec), Toast.LENGTH_SHORT).show()
                    arrayList.removeAt(position)
                    notifyDataSetChanged()
                    notifyDataSetInvalidated()
                    alertDialog.dismiss()
                    if (arrayList.isEmpty()){
                      lottie.visibility=View.VISIBLE
                        card.visibility=View.GONE
                    }
                }else{
                    Toast.makeText(c, c.resources.getString(R.string.toastError), Toast.LENGTH_SHORT).show()
                }
            }
        }
        view.btn_done_delete_Sec_with_two_options_dialog.setOnClickListener {
            if (view.delete_the_section_but_move_its_data_to_another_section.isChecked){
                val sectionsArray=db.getSectionsName()
                sectionsArray.removeAt(position)
                if (sectionsArray.isNotEmpty()) {
                    showSectionDialog(position, alertDialog, sectionsArray)
                }else{
                    Toast.makeText(c, c.resources.getString(R.string.toastYouMustEnterSectionFirst), Toast.LENGTH_SHORT).show()
                }

            }else if (view.delete_the_section_without_moving_its_data_to_another_section.isChecked){

                showDeleteDialogWhenUserChooseWithout(view,position,alertDialog)
            }else{

                Toast.makeText(c, c.resources.getString(R.string.plz_pick), Toast.LENGTH_SHORT).show()
            }
        }

        view.btn_cancel_delete_Sec_dialog.setOnClickListener {
            alertDialog.dismiss()
        }

        view.btn_cancel_delete_Sec_with_two_options_dialog.setOnClickListener {
            alertDialog.dismiss()
        }
        alertDialog.show()
    }

    private fun showDeleteDialogWhenUserChooseWithout(view:View,position: Int,alertDialog: AlertDialog) {
        view.radioGroupSec.visibility=View.GONE
        view.linearLayout2Sec.visibility=View.GONE
        view.radioGroupSecForExp.visibility=View.VISIBLE
        view.linearLayout2SecForExp.visibility=View.VISIBLE

        view.btn_done_delete_Sec_Exp_with_two_options_dialog.setOnClickListener {

            if (view.delete_the_expenseAndSec_and_return_the_amount_to_the_wallet.isChecked){
                try {


                    val sharedPreferences =
                        c.getSharedPreferences(shared_wallet_file_name, Context.MODE_PRIVATE)
                    val oldBalance = sharedPreferences.getFloat(shared_wallet_balance, 0.0f)
                    val oldExpenses = sharedPreferences.getFloat(shared_wallet_expenses, 0.0f)
                    val sum = db.clearSectionAndReturnSumOfExpenses(arrayList[position].name)
                    val newBalance = oldBalance + sum
                    val newExpenses = oldExpenses - sum
                    sharedPreferences.edit().putFloat(shared_wallet_balance, newBalance).apply()
                    sharedPreferences.edit().putFloat(shared_wallet_expenses, newExpenses).apply()
                    Toast.makeText(
                        c,
                        c.resources.getString(R.string.toastDeleteSec),
                        Toast.LENGTH_SHORT
                    ).show()
                    arrayList.removeAt(position)
                    notifyDataSetChanged()
                    notifyDataSetInvalidated()
                    alertDialog.dismiss()
                }catch (e:Exception){
                    Toast.makeText(c, e.message, Toast.LENGTH_LONG).show()
                }
            }else if (view.delete_the_expenseAndSec_without_returning_the_amount_to_the_wallet.isChecked){
                    val delete=db.clearExpenseAndSectionFormSectionName(arrayList[position].name)
                    if (delete){
                        Toast.makeText(c, c.resources.getString(R.string.toastDeleteSec), Toast.LENGTH_SHORT).show()
                        arrayList.removeAt(position)
                        notifyDataSetChanged()
                        notifyDataSetInvalidated()
                        alertDialog.dismiss()
                    }else{
                        Toast.makeText(c, c.resources.getString(R.string.toastError), Toast.LENGTH_SHORT).show()
                    }
            }else{
                    Toast.makeText(c, c.resources.getString(R.string.plz_pick), Toast.LENGTH_SHORT).show()
            }

        }
        view.btn_cancel_delete_Sec_Exp_with_two_options_dialog.setOnClickListener {
            alertDialog.dismiss()
        }

    }



    private fun showSectionDialog(position: Int,parentDialog:AlertDialog,sectionsArray:ArrayList<String>):View {
        val view = LayoutInflater.from(c).inflate(R.layout.sectio_name_array, null)
        val alertDialog =AlertDialog.Builder(c, R.style.CustomAlertDialog).create()
        alertDialog.setCanceledOnTouchOutside(false)
        alertDialog.setView(view)
        view.list_forSectiosNames_dialog.setOnItemClickListener { parent, view, position, id ->
            try {


            val name = parent.getItemAtPosition(position)
            val delete = db.clearSectionWithMoveData(arrayList[position].name, name.toString())
            if (delete) {
                Toast.makeText(
                    c,
                    c.resources.getString(R.string.toastDeleteSec),
                    Toast.LENGTH_SHORT
                ).show()
                arrayList.removeAt(position)
                notifyDataSetChanged()
                notifyDataSetInvalidated()
                alertDialog.dismiss()
                parentDialog.dismiss()

            } else {
                Toast.makeText(c, c.resources.getString(R.string.toastError), Toast.LENGTH_SHORT)
                    .show()
            }
        }catch (e:Exception){
                Toast.makeText(c, e.message, Toast.LENGTH_LONG).show()
        }

            alertDialog.dismiss()
        }

        val textWatcher = object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                try {
                    val sectionsArray=db.searchForSectionsTitle(p0.toString())
                    sectionsArray.removeAt(position)
                    view.list_forSectiosNames_dialog.adapter = ArrayAdapter(c, R.layout.dropmenu, sectionsArray)

                }catch (e:Exception){
                    Toast.makeText(c, e.message, Toast.LENGTH_SHORT).show()
                }
            }

            override fun afterTextChanged(p0: Editable?) {
            }
        }
        view.list_forSectiosNames_dialog.adapter = ArrayAdapter(c,  R.layout.dropmenu, sectionsArray)
        view.btn_cancel_setion_names_dialog.setOnClickListener {
            alertDialog.dismiss()
        }
        alertDialog.show()

        return view
    }

}