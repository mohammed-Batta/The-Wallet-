package com.example.thewallet.add_fragments

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.thewallet.activitys.LoginA.Companion.db
import com.example.thewallet.R
import com.example.thewallet.activitys.MainActivity
import com.example.thewallet.luxuries.ForDataCurrency
import com.example.thewallet.luxuries.currency_key
import com.example.thewallet.luxuries.shared_settings_file_name
import com.example.thewallet.luxuries.shared_wallet_balance
import com.example.thewallet.luxuries.shared_wallet_expenses
import com.example.thewallet.luxuries.shared_wallet_file_name
import kotlinx.android.synthetic.main.fragment_add_exp.view.btn_save_AddExp
import kotlinx.android.synthetic.main.fragment_add_exp.view.currencyAddExp
import kotlinx.android.synthetic.main.fragment_add_exp.view.et_Expense_description
import kotlinx.android.synthetic.main.fragment_add_exp.view.et_Expense_name
import kotlinx.android.synthetic.main.fragment_add_exp.view.et_Expense_price
import kotlinx.android.synthetic.main.fragment_add_exp.view.et_Section_name_Exp
import kotlinx.android.synthetic.main.fragment_add_exp.view.et_date_picker
import kotlinx.android.synthetic.main.fragment_add_exp.view.iv_backFromAddExp
import kotlinx.android.synthetic.main.fragment_add_exp.view.tv_AddExp
import kotlinx.android.synthetic.main.fragment_add_exp.view.tv_walletBalanceAddExp
import kotlinx.android.synthetic.main.sectio_name_array.view.btn_cancel_setion_names_dialog
import kotlinx.android.synthetic.main.sectio_name_array.view.et_Search_sectioName_dialog
import kotlinx.android.synthetic.main.sectio_name_array.view.list_forSectiosNames_dialog
import java.util.Calendar


class AddExpense : Fragment() {
    private var theDay :Int?=null
    private var theMonth :Int?=null
    private var theYear :Int?=null
    @SuppressLint("InflateParams", "SetTextI18n")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        val inf=inflater.inflate(R.layout.fragment_add_exp, container, false)
        try {
            val sharedPreferences=requireContext().getSharedPreferences(shared_wallet_file_name,Context.MODE_PRIVATE)
            val showBalance= sharedPreferences.getFloat(shared_wallet_balance,0f)
            inf.tv_walletBalanceAddExp.text = "$showBalance"
            val sharedPreferences2=requireContext().getSharedPreferences(shared_settings_file_name,Context.MODE_PRIVATE)
            val currency=sharedPreferences2.getInt(currency_key,0)
            inf.currencyAddExp.text = ForDataCurrency[currency]


            when (this.resources.configuration?.uiMode?.and(Configuration.UI_MODE_NIGHT_MASK)) {
                Configuration.UI_MODE_NIGHT_YES -> {
                    inf.tv_AddExp.setTextColor(Color.WHITE)
                    inf.et_Expense_name.setTextColor(Color.WHITE)
                    inf.et_Expense_description.setTextColor(Color.WHITE)
                    inf.et_Expense_price.setTextColor(Color.WHITE)
                    inf.et_date_picker.setTextColor(Color.WHITE)

                }

                Configuration.UI_MODE_NIGHT_NO -> {
                    inf.tv_AddExp.setTextColor(Color.BLACK)
                    inf.et_Expense_name.setTextColor(Color.BLACK)
                    inf.et_Expense_description.setTextColor(Color.BLACK)
                    inf.et_Expense_price.setTextColor(Color.BLACK)
                    inf.et_date_picker.setTextColor(Color.BLACK)

                }

            }



            inf.iv_backFromAddExp.setOnClickListener {
                findNavController().popBackStack(R.id.homeFragment, false)
            }

            inf.et_Section_name_Exp.setOnClickListener {
                try {
                    showSectionDialog(inf)

                } catch (e: Exception) {
                    Toast.makeText(requireContext(), e.message, Toast.LENGTH_SHORT).show()
                }
            }

            inf.btn_save_AddExp.setOnClickListener {
                val balance= sharedPreferences.getFloat(shared_wallet_balance,0f)
                val oldExpenses= sharedPreferences.getFloat(shared_wallet_expenses,0f)
                val name = inf.et_Expense_name.text.toString().trim()
                val description = inf.et_Expense_description.text.toString().trim()
                val price = inf.et_Expense_price.text.toString().trim()
                val sectio_name = inf.et_Section_name_Exp.text.toString().trim()
                if (name.isNotEmpty() && description.isNotEmpty() && price.isNotEmpty()
                    && sectio_name.isNotEmpty()&&theDay!=null&&theMonth!=null&&theYear!=null) {
                    if (canAddExpense(balance,price.toFloat())) {
                        val result = db.addExpenses(
                            name,
                            description,
                            theDay!!,
                            theMonth!!,
                            theYear!!,
                            price.toFloat(),
                            sectio_name
                        )

                        if (result) {
                            inf.et_Expense_name.text?.clear()
                            inf.et_Expense_description.text?.clear()
                            inf.et_Expense_price.text?.clear()
                            inf.et_Section_name_Exp.text?.clear()
                            inf.et_date_picker.text?.clear()
                            theDay=null
                            theMonth=null
                            theYear=null
                            val newBalance=balance-price.toFloat()
                            val newExpenses=oldExpenses+price.toFloat()
                            sharedPreferences.edit().putFloat(shared_wallet_balance,newBalance).apply()
                            sharedPreferences.edit().putFloat(shared_wallet_expenses,newExpenses).apply()
                            inf.tv_walletBalanceAddExp.text = "$newBalance"
                            Toast.makeText(
                                requireContext(),
                                resources.getString(R.string.toastAddExp),
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            Toast.makeText(
                                requireContext(),
                                resources.getString(R.string.toastFiledAddExp),
                                Toast.LENGTH_SHORT
                            ).show()
                        }

                    }else{
                        Toast.makeText(requireContext(), resources.getString(R.string.toasNoBalance), Toast.LENGTH_LONG).show()
                        inf.et_Expense_price.text?.clear()
                    }

                }else{
                    Toast.makeText(requireContext(), resources.getString(R.string.fillet), Toast.LENGTH_SHORT).show()
                }
            }


            val c = Calendar.getInstance()
            val year = c.get(Calendar.YEAR)
            val month = c.get(Calendar.MONTH)
            val day = c.get(Calendar.DAY_OF_MONTH)

            val datePickerDialog =
                DatePickerDialog(requireContext(), { view, year, monthOfYear, dayOfMonth ->
                    try {
                        theDay = dayOfMonth
                        theMonth = monthOfYear + 1
                        theYear = year
                        inf.et_date_picker.setText("$theDay-$theMonth-$theYear")
                    } catch (e: Exception) {
                        Toast.makeText(requireContext(), e.message, Toast.LENGTH_SHORT).show()
                    }
                }, year, month, day)


            inf.et_date_picker.setOnClickListener {
                datePickerDialog.show()
            }
        }catch (e:Exception){
            Toast.makeText(requireContext(), e.message, Toast.LENGTH_SHORT).show()
        }
        return inf
    }

    private fun canAddExpense(balance:Float,newExpense: Float): Boolean {
        val math=balance-newExpense
        return math>=0f
    }

    private fun showSectionDialog(inf:View) {
        val view = LayoutInflater.from(requireContext()).inflate(R.layout.sectio_name_array, null)
        val alertDialog =AlertDialog.Builder(requireContext(), R.style.CustomAlertDialog).create()
        alertDialog.setCanceledOnTouchOutside(false)
        alertDialog.setView(view)
        view.list_forSectiosNames_dialog.setOnItemClickListener { parent, view, position, id ->
            val name = parent.getItemAtPosition(position)
            inf.et_Section_name_Exp.setText(name.toString())
            alertDialog.dismiss()
        }

        val textWatcher = object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                try {
                    val filter = db.searchForSectionsNameJustName(p0.toString())
                    view.list_forSectiosNames_dialog.adapter = ArrayAdapter(requireContext(), R.layout.dropmenu, filter)

                }catch (e:Exception){
                    Toast.makeText(requireContext(), e.message, Toast.LENGTH_SHORT).show()
                }
            }

            override fun afterTextChanged(p0: Editable?) {
            }
        }
        view.et_Search_sectioName_dialog.addTextChangedListener(textWatcher)

        view.list_forSectiosNames_dialog.adapter = ArrayAdapter(requireContext(),  R.layout.dropmenu, db.getSectionsName())
        view.btn_cancel_setion_names_dialog.setOnClickListener {
            alertDialog.dismiss()
        }
        alertDialog.show()
    }

    override fun onAttach(context: Context) {
        (activity as MainActivity).hideBottomNavigation()
        super.onAttach(context)
    }

    override fun onDetach() {
        super.onDetach()
        (activity as MainActivity).showBottomNavigation()
    }
}