package com.example.thewallet.luxuries

import android.content.Context
import de.hdodenhof.circleimageview.CircleImageView
import java.io.File
import java.io.FileInputStream
import java.util.Locale


object LocaleHelper {

    fun setLocale(context: Context, language: String): Context {

       return updateResourcesLegacy(context, language)
    }

    }

    @Suppress("deprecation")
    private fun updateResourcesLegacy(context: Context, language: String): Context {
        val locale = Locale(language)
        Locale.setDefault(locale)
        val resources = context.resources
        val configuration = resources.configuration
        configuration.locale = locale
        configuration.setLayoutDirection(locale)
        resources.updateConfiguration(configuration, resources.displayMetrics)
        return context
    }

fun readImageFromInStorge(app:Context, imageView: CircleImageView){
        val context = app.applicationContext
        val directory = context.filesDir
        val file = File(directory, "image.txt")
        val inputStream = FileInputStream(file)
        val data = inputStream.readBytes()
        inputStream.close()
        imageView.setImageBitmap(Utils.getImage(data))

}


