package com.example.thewallet.edit_fragments

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.example.thewallet.R
import com.example.thewallet.activitys.LoginA
import com.example.thewallet.activitys.LoginA.Companion.db
import com.example.thewallet.activitys.MainActivity
import com.example.thewallet.luxuries.SEC_BACK
import com.example.thewallet.luxuries.SEC_DES
import com.example.thewallet.luxuries.SEC_NAME
import kotlinx.android.synthetic.main.fragment_add_sec.view.et_Section_description
import kotlinx.android.synthetic.main.fragment_add_sec.view.et_Section_name
import kotlinx.android.synthetic.main.fragment_edit_section.btn_save_editSec
import kotlinx.android.synthetic.main.fragment_edit_section.view.btn_save_editSec
import kotlinx.android.synthetic.main.fragment_edit_section.view.et_Section_edit_description
import kotlinx.android.synthetic.main.fragment_edit_section.view.et_Section_edit_name
import kotlinx.android.synthetic.main.fragment_edit_section.view.iv_backFromEditSec
import kotlinx.android.synthetic.main.fragment_edit_section.view.tv_EditSec

class EditSection : Fragment() {

    private var param_name: String? = null
    private var param_des: String? = null
    private var param_back: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param_name = it.getString(SEC_NAME)
            param_des = it.getString(SEC_DES)
            param_back = it.getInt(SEC_BACK)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        val inf=inflater.inflate(R.layout.fragment_edit_section, container, false)


        when (this.resources.configuration?.uiMode?.and(Configuration.UI_MODE_NIGHT_MASK)) {
            Configuration.UI_MODE_NIGHT_YES -> {
                inf.tv_EditSec.setTextColor(Color.WHITE)
                inf.et_Section_edit_description.setTextColor(Color.WHITE)
                inf.et_Section_edit_name.setTextColor(Color.WHITE)
            }

            Configuration.UI_MODE_NIGHT_NO -> {
                inf.tv_EditSec.setTextColor(Color.BLACK)
                inf.et_Section_edit_description.setTextColor(Color.BLACK)
                inf.et_Section_edit_name.setTextColor(Color.BLACK)

            }

        }
        inf.et_Section_edit_name.setText(param_name)
        inf.et_Section_edit_description.setText(param_des)
        inf.btn_save_editSec.setOnClickListener {
            val name=inf.et_Section_edit_name.text.toString().trim()
            val description=inf.et_Section_edit_description.text.toString().trim()
            if (name.isNotEmpty()&&description.isNotEmpty()){
                val result =db.updateSection(param_name!!,name, description)
                if (result) {
                    Toast.makeText(requireContext(), resources.getString(R.string.toastEditSec), Toast.LENGTH_LONG).show()
                }else{
                    Toast.makeText(requireContext(), resources.getString(R.string.toastTheNameIsSame), Toast.LENGTH_LONG).show()
                }
            }else{
                Toast.makeText(requireContext(), resources.getString(R.string.fillet), Toast.LENGTH_LONG).show()
            }

        }

        inf.iv_backFromEditSec.setOnClickListener {
            findNavController().popBackStack(param_back!!,false)
        }


        return inf
    }
    override fun onAttach(context: Context) {
        (activity as MainActivity).hideBottomNavigation()
        super.onAttach(context)
    }

    override fun onDetach() {
        super.onDetach()
        (activity as MainActivity).showBottomNavigation()
    }


}