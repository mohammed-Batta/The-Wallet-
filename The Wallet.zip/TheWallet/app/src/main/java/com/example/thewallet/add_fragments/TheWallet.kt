package com.example.thewallet.add_fragments

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.thewallet.R
import com.example.thewallet.activitys.MainActivity
import com.example.thewallet.luxuries.ForDataCurrency
import com.example.thewallet.luxuries.currency_key
import com.example.thewallet.luxuries.shared_settings_file_name
import com.example.thewallet.luxuries.shared_wallet_additions
import com.example.thewallet.luxuries.shared_wallet_balance
import com.example.thewallet.luxuries.shared_wallet_file_name
import kotlinx.android.synthetic.main.fragment_the_wallet.view.btn_walletBalance
import kotlinx.android.synthetic.main.fragment_the_wallet.view.cAmount
import kotlinx.android.synthetic.main.fragment_the_wallet.view.currencyAddWallet
import kotlinx.android.synthetic.main.fragment_the_wallet.view.et_walletBalance
import kotlinx.android.synthetic.main.fragment_the_wallet.view.iv_backFromAddBalance
import kotlinx.android.synthetic.main.fragment_the_wallet.view.tv_walletBalance


class TheWallet : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        val inf=inflater.inflate(R.layout.fragment_the_wallet, container, false)
        val sharedPreferences=requireContext().getSharedPreferences(shared_wallet_file_name,Context.MODE_PRIVATE)
       val showBalance= sharedPreferences.getFloat(shared_wallet_balance,0.0f)
        inf.tv_walletBalance.text = "$showBalance"

        val sharedPreferences2=requireContext().getSharedPreferences(shared_settings_file_name,Context.MODE_PRIVATE)
        val currency=sharedPreferences2.getInt(currency_key,0)
        inf.currencyAddWallet.text = ForDataCurrency[currency]
        inf.cAmount.text = ForDataCurrency[currency]


        inf.btn_walletBalance.setOnClickListener {
            val newBalance=inf.et_walletBalance.text.toString().trim()
            val oldBalance= sharedPreferences.getFloat(shared_wallet_balance,0.0f)
            val oldAddition= sharedPreferences.getFloat(shared_wallet_additions,0.0f)
            if (newBalance.isNotEmpty()){
                val added=oldBalance+newBalance.toFloat()
                val addedAdditions=oldAddition+newBalance.toFloat()
                sharedPreferences.edit().putFloat(shared_wallet_balance,added).apply()
                sharedPreferences.edit().putFloat(shared_wallet_additions,addedAdditions).apply()
                Toast.makeText(requireContext(), resources.getString(R.string.toastadded), Toast.LENGTH_SHORT).show()
                inf.tv_walletBalance.text = "$added"
                inf.et_walletBalance.text.clear()
            }
        }
      inf.iv_backFromAddBalance.setOnClickListener {

            findNavController().popBackStack(R.id.homeFragment,false)
        }

        return inf
    }

    override fun onAttach(context: Context) {
        (activity as MainActivity).hideBottomNavigation()
        super.onAttach(context)
    }

    override fun onDetach() {
        super.onDetach()
        (activity as MainActivity).showBottomNavigation()
    }
}