package com.example.thewallet

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.DatabaseUtils
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import com.example.thewallet.dataclasss.Expenses
import com.example.thewallet.dataclasss.Section


class DataBase(val context: Context): SQLiteOpenHelper(context,"Home",null,2) {

    private val expenses_table = "Expenses"
    private val expenses_id = "id"
    private val expenses_name = "name"
    private val expenses_day = "day"
    private val expenses_month = "month"
    private val expenses_year = "year"
    private val expenses_des = "des"
    private val expenses_price = "price"
    private val section_id = "section_name"

    private val section_table = "Section"
    private val section_name = "name"
    private val section_des = "des"


    override fun onCreate(x: SQLiteDatabase?) {
        x?.execSQL("create table $expenses_table($expenses_id integer primary key autoincrement ,$expenses_name text,$expenses_des text,$expenses_day text,$expenses_month text,$expenses_year text,$expenses_price real,$section_id Text);")
        x?.execSQL("create table $section_table($section_name Text primary key,$section_des text);")
    }

    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {
        p0?.execSQL("DROP TABLE IF EXISTS $expenses_table ;")
        p0?.execSQL("DROP TABLE IF EXISTS $section_table ;")
        onCreate(p0)
    }

    fun addExpenses(
        name: String,
        description: String,
        day: Int,
        month: Int,
        year: Int,
        price: Float,
        section: String
    ): Boolean {
        val db = this.writableDatabase
        val cv = ContentValues()
        cv.put(expenses_name, name)
        cv.put(expenses_day, day)
        cv.put(expenses_month, month)
        cv.put(expenses_year, year)
        cv.put(expenses_des, description)
        cv.put(expenses_price, price)
        cv.put(section_id, section)
        val result = db.insert(expenses_table, null, cv)
        return result != -1L
    }

    fun getAllExpenses(): ArrayList<Expenses> {
        val db = this.readableDatabase
        val cursor = db.rawQuery("select * from $expenses_table", null)
        val myArray = ArrayList<Expenses>()
        while (cursor.moveToNext()) {
            val id = cursor.getInt(0)
            val name = cursor.getString(1)
            val description = cursor.getString(2)
            val day = cursor.getInt(3)
            val month = cursor.getInt(4)
            val year = cursor.getInt(5)
            val price = cursor.getFloat(6)
            val sectionName = cursor.getString(7)
            myArray.add(Expenses(id, name, description, day, month, year, price, sectionName))
        }
        cursor.close()
        db.close()
        return myArray
    }


    fun getExpenseOnSection(section: String): ArrayList<Expenses> {
        val db = this.readableDatabase
        val cursor =
            db.rawQuery("select * from $expenses_table where $section_id =\'$section\'; ", null)
        val myArray = ArrayList<Expenses>()
        while (cursor.moveToNext()) {
            val id = cursor.getInt(0)
            val name = cursor.getString(1)
            val description = cursor.getString(2)
            val day = cursor.getInt(3)
            val month = cursor.getInt(4)
            val year = cursor.getInt(5)
            val price = cursor.getFloat(6)
            val sectionName = cursor.getString(7)
            myArray.add(Expenses(id, name, description, day, month, year, price, sectionName))
        }
        cursor.close()
        db.close()
        return myArray
    }


    fun clearExpense(id: String): Boolean {
        val db = this.writableDatabase
        var result = false
        try {
            db.execSQL("Delete From $expenses_table where $expenses_id =\'$id\';")
            result = true
        } catch (ex: Exception) {
            Log.e("asd", "Error,delete")
        }
        db.close()
        return result
    }

    fun clearExpenseAndSectionFormSectionName(id: String): Boolean {
        val db = this.writableDatabase
        var result = false
        try {
            db.execSQL("Delete From $expenses_table where $section_id =\'$id\';")
            db.execSQL("Delete From $section_table where $section_name =\'$id\';")
            result = true
        } catch (ex: Exception) {
            Log.e("asd", "Error,delete")
        }
        db.close()
        return result
    }

    @SuppressLint("Recycle")
    fun clearSectionAndReturnSumOfExpenses(id: String): Float {
        val db = this.readableDatabase
        var sum = 0f
        val cursor = db.rawQuery(
            "select $expenses_price from $expenses_table where $section_id =\'$id\';",
            null
        )
        while (cursor.moveToNext()) {
            sum += cursor.getFloat(0)
        }
        db.execSQL("Delete From $expenses_table where $section_id =\'$id\';")
        db.execSQL("Delete From $section_table where $section_name =\'$id\';")
        db.close()
        return sum
    }


    fun updateExpense(
        id: String,
        name: String,
        description: String,
        day: Int,
        month: Int,
        year: Int,
        price: Float,
        section: String
    ): Boolean {
        val db = this.writableDatabase
        val cv = ContentValues()
        cv.put(expenses_name, name)
        cv.put(expenses_day, day)
        cv.put(expenses_month, month)
        cv.put(expenses_year, year)
        cv.put(expenses_des, description)
        cv.put(expenses_price, price)
        cv.put(section_id, section)
        val re: Boolean = try {
            db.update(expenses_table, cv, "$expenses_id = ?", arrayOf(id))
            true
        } catch (rx: Exception) {
            false
        }
        db.close()
        return re
    }

    fun clearAllExpenses() {
        val write = this.writableDatabase
        write.delete(expenses_table, null, null)
        write.close()
    }


    fun addSections(name: String, description: String): Boolean {
        val db = this.writableDatabase
        val cv = ContentValues()
        cv.put(section_name, name)
        cv.put(section_des, description)
        val result = db.insert(section_table, null, cv)
        return result != -1L
    }

    fun getAllSections(): ArrayList<Section> {
        val db = this.readableDatabase
        val cursor = db.rawQuery("select * from $section_table;", null)
        val myArray = ArrayList<Section>()
        while (cursor.moveToNext()) {
            val name = cursor.getString(0)
            val description = cursor.getString(1)
            myArray.add(Section(name, description))
        }
        cursor.close()
        db.close()
        return myArray
    }


    fun getSectionsCount(): Long {
        val db = this.readableDatabase
        val count = DatabaseUtils.queryNumEntries(db, section_table)
        db.close()
        return count
    }

    fun getExpensesCount(): Long {
        val db = this.readableDatabase
        val count = DatabaseUtils.queryNumEntries(db, expenses_table)
        db.close()
        return count
    }


    fun getSectionsName(): ArrayList<String> {
        val db = this.readableDatabase
        val cursor = db.rawQuery("select $section_name from $section_table;", null)
        val myArray = ArrayList<String>()
        while (cursor.moveToNext()) {
            val name = cursor.getString(0)
            myArray.add(name)
        }
        cursor.close()
        db.close()
        return myArray
    }

    fun searchForSectionsTitle(search: String): ArrayList<Section> {
        val db = this.readableDatabase
        val cursor = db.rawQuery(
            "select * from $section_table where $section_name LIKE '%$search%';",
            null
        )
        val myArray = ArrayList<Section>()
        while (cursor.moveToNext()) {
            val name = cursor.getString(0)
            val description = cursor.getString(1)
            myArray.add(Section(name, description))
        }
        cursor.close()
        db.close()
        return myArray
    }

    fun searchForSectionsAny(search: String): ArrayList<Section> {
        val db = this.readableDatabase
        val cursor = db.rawQuery(
            "select * from $section_table where $section_name LIKE '%$search%' OR $section_des LIKE '%$search%' ;",
            null
        )
        val myArray = ArrayList<Section>()
        while (cursor.moveToNext()) {
            val name = cursor.getString(0)
            val description = cursor.getString(1)
            myArray.add(Section(name, description))
        }
        cursor.close()
        db.close()
        return myArray
    }

    fun searchForSectionsNameJustName(search: String): ArrayList<String> {
        val db = this.readableDatabase
        val cursor = db.rawQuery(
            "select $section_name from $section_table where $section_name LIKE '%$search%';",
            null
        )
        val myArray = ArrayList<String>()
        while (cursor.moveToNext()) {
            val name = cursor.getString(0)
            myArray.add(name)
        }
        cursor.close()
        db.close()
        return myArray
    }

    fun searchForExpNameWithSectionId(section: String, search: String): ArrayList<Expenses> {
        val db = this.readableDatabase
        val cursor = db.rawQuery(
            "select * from $expenses_table where $section_id LIKE '%$section%' AND (($expenses_name LIKE '%$search%') OR ($expenses_des LIKE '%$search%') OR ($expenses_price LIKE '%$search%') OR ($expenses_day LIKE '%$search%') OR ($expenses_month LIKE '%$search%') OR ($expenses_year LIKE '%$search%'));",
            null
        )
        val myArray = ArrayList<Expenses>()
        while (cursor.moveToNext()) {
            val id = cursor.getInt(0)
            val name = cursor.getString(1)
            val description = cursor.getString(2)
            val day = cursor.getInt(3)
            val month = cursor.getInt(4)
            val year = cursor.getInt(5)
            val price = cursor.getFloat(6)
            val sectionName = cursor.getString(7)
            myArray.add(Expenses(id, name, description, day, month, year, price, sectionName))
        }
        cursor.close()
        db.close()
        return myArray
    }

    fun searchForExpNameWithOutSectionId(search: String): ArrayList<Expenses> {
        val db = this.readableDatabase
        val cursor = db.rawQuery(
            "select * from $expenses_table where $expenses_name LIKE '%$search%' OR $expenses_des LIKE '%$search%' OR $expenses_price LIKE '%$search%' OR $expenses_day LIKE '%$search%' OR $expenses_month LIKE '%$search%' OR $expenses_year LIKE '%$search%';",
            null
        )
        val myArray = ArrayList<Expenses>()
        while (cursor.moveToNext()) {
            val id = cursor.getInt(0)
            val name = cursor.getString(1)
            val description = cursor.getString(2)
            val day = cursor.getInt(3)
            val month = cursor.getInt(4)
            val year = cursor.getInt(5)
            val price = cursor.getFloat(6)
            val sectionName = cursor.getString(7)
            myArray.add(Expenses(id, name, description, day, month, year, price, sectionName))
        }
        cursor.close()
        db.close()
        return myArray
    }

    fun searchForExpNameByName(search: String): ArrayList<Expenses> {
        val db = this.readableDatabase
        val cursor = db.rawQuery(
            "select * from $expenses_table where $expenses_name LIKE '%$search%';",
            null
        )
        val myArray = ArrayList<Expenses>()
        while (cursor.moveToNext()) {
            val id = cursor.getInt(0)
            val name = cursor.getString(1)
            val description = cursor.getString(2)
            val day = cursor.getInt(3)
            val month = cursor.getInt(4)
            val year = cursor.getInt(5)
            val price = cursor.getFloat(6)
            val sectionName = cursor.getString(7)
            myArray.add(Expenses(id, name, description, day, month, year, price, sectionName))
        }
        cursor.close()
        db.close()
        return myArray
    }


    fun clearSection(name: String): Boolean {
        val s = "Delete From $section_table where $section_name =\'$name\';"
        val m = "Delete From $expenses_table where $section_id =\'$name\';"
        val db = this.writableDatabase
        var re = false
        try {
            db.execSQL(s)
            db.execSQL(m)
            re = true
        } catch (ex: Exception) {
            Log.e("asd", "Error,delete")
        }
        db.close()
        return re
    }

    fun clearSectionWithMoveData(oldName: String, newName: String): Boolean {
        val db = this.writableDatabase
        db.execSQL("Delete From $section_table where $section_name =\'$oldName\';")
        val cv = ContentValues()
        cv.put(section_id, newName)
        val result = db.update(expenses_table, cv, "$section_id =\'$oldName\'", null)
        db.close()
        return result > 0
    }


    fun updateSection(oldName: String, newName: String, description: String): Boolean {
        val db = this.writableDatabase
        val cv1 = ContentValues()
        cv1.put(section_name, newName)
        cv1.put(section_des, description)
        val cv2 = ContentValues()
        cv2.put(section_id, newName)
        val result: Boolean = try {
            db.update(section_table, cv1, "$section_name = ?", arrayOf(oldName))
            db.update(expenses_table, cv2, "$section_id =\'$oldName\'", null)
            true
        } catch (rx: Exception) {
            false
        }
        db.close()
        return result
    }

    fun clearAllSections() {
        val write = this.writableDatabase
        write.delete(section_table, null, null)
        write.delete(expenses_table, null, null)
        write.close()
    }


}

