package com.example.thewallet.view_fragments

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.view.isVisible
import androidx.navigation.fragment.findNavController
import com.example.thewallet.luxuries.EXP_DAY
import com.example.thewallet.luxuries.EXP_DES
import com.example.thewallet.luxuries.EXP_ID
import com.example.thewallet.luxuries.EXP_MONTH
import com.example.thewallet.luxuries.EXP_NAME
import com.example.thewallet.luxuries.EXP_PRICE
import com.example.thewallet.luxuries.EXP_SECTION_NAME
import com.example.thewallet.luxuries.EXP_YEAR
import com.example.thewallet.activitys.LoginA.Companion.db
import com.example.thewallet.R
import com.example.thewallet.adapters.ExpenseAdapter
import com.example.thewallet.activitys.MainActivity
import com.example.thewallet.luxuries.EXP_BACK
import kotlinx.android.synthetic.main.fragment_search_section.view.liner2_section_search
import kotlinx.android.synthetic.main.fragment_search_section.view.nodataLottie
import kotlinx.android.synthetic.main.fragment_view_exp_and_edit.view.et_Search_name_Sec_exp
import kotlinx.android.synthetic.main.fragment_view_exp_and_edit.view.iv_backFromView_edit_Exp
import kotlinx.android.synthetic.main.fragment_view_exp_and_edit.view.liner3
import kotlinx.android.synthetic.main.fragment_view_exp_and_edit.view.listView_in_ViewAndEditExpScreen
import kotlinx.android.synthetic.main.fragment_view_exp_and_edit.view.nodataLottie_viewexp
import kotlinx.android.synthetic.main.fragment_view_exp_and_edit.view.tv_viewAndEditExp
import kotlinx.android.synthetic.main.sectio_name_array.view.btn_cancel_setion_names_dialog
import kotlinx.android.synthetic.main.sectio_name_array.view.et_Search_sectioName_dialog
import kotlinx.android.synthetic.main.sectio_name_array.view.list_forSectiosNames_dialog

class ViewExpense : Fragment() {
    companion object {
        @JvmStatic
        fun bundleExpense(id:String, name: String, description: String, price:Float, section_name:String, day:Int, month:Int, year:Int,back:Int) =
            ViewExpense().apply {
                arguments=Bundle().apply {
                    putString(EXP_ID, id)
                    putString(EXP_NAME, name)
                    putString(EXP_DES, description)
                    putFloat(EXP_PRICE, price)
                    putString(EXP_SECTION_NAME, section_name)
                    putInt(EXP_DAY, day)
                    putInt(EXP_MONTH, month)
                    putInt(EXP_YEAR, year)
                    putInt(EXP_BACK, back)
                }
            }
    }

    private val action=R.id.action_viewExpAndEdit_to_editExp
    private val back=R.id.viewExpAndEdit

    @SuppressLint("ResourceAsColor")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val inf=inflater.inflate(R.layout.fragment_view_exp_and_edit, container, false)
        try {
            when (this.resources.configuration?.uiMode?.and(Configuration.UI_MODE_NIGHT_MASK)) {
                Configuration.UI_MODE_NIGHT_YES -> {
                    inf.tv_viewAndEditExp.setTextColor(Color.WHITE)
                }

                Configuration.UI_MODE_NIGHT_NO -> {
                    inf.tv_viewAndEditExp.setTextColor(Color.BLACK)
                }

            }

            if (db.getExpensesCount()>0L){
                inf.liner3.visibility=View.VISIBLE
                inf.nodataLottie_viewexp.visibility=View.GONE
                inf.liner3.setBackgroundColor(R.color.Dark)
            }

            inf.iv_backFromView_edit_Exp.setOnClickListener {
                findNavController().popBackStack(R.id.homeFragment,false)
            }
            inf.listView_in_ViewAndEditExpScreen.adapter = ExpenseAdapter(requireContext(), db.getAllExpenses(),this,action,back,inf.nodataLottie_viewexp,inf.liner3,inf.et_Search_name_Sec_exp)

            val textWatcher = object : TextWatcher {
                override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                }

                override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                    try {
                        val filter = db.searchForExpNameByName(p0.toString())
                        inf.listView_in_ViewAndEditExpScreen.adapter = ExpenseAdapter(requireContext(), filter, this@ViewExpense,action,back,inf.nodataLottie_viewexp,inf.liner3,inf.et_Search_name_Sec_exp)
                    }catch (e:Exception){
                        Toast.makeText(requireContext(), e.message, Toast.LENGTH_SHORT).show()
                    }
                }

                override fun afterTextChanged(p0: Editable?) {
                }
            }
            inf.et_Search_name_Sec_exp.addTextChangedListener(textWatcher)

        }catch (e:Exception){
            Toast.makeText(requireContext(), e.message, Toast.LENGTH_LONG).show()
        }
        return inf
    }


    override fun onAttach(context: Context) {
        (activity as MainActivity).hideBottomNavigation()
        super.onAttach(context)
    }

    override fun onResume() {
        super.onResume()
        (activity as MainActivity).hideBottomNavigation()
    }

    override fun onDetach() {
        super.onDetach()
        (activity as MainActivity).showBottomNavigation()
    }

}