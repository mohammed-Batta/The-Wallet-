package com.example.thewallet.dataclasss

import android.accounts.AuthenticatorDescription
import java.time.Month

data class Expenses(val id:Int,val name:String,val description: String,val day:Int,val month:Int,val year:Int,val price:Float,val sectionname: String)
