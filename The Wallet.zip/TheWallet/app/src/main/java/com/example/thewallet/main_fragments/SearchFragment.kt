package com.example.thewallet.main_fragments

import android.annotation.SuppressLint
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.thewallet.R
import com.example.thewallet.search_fragments.SearchExpense
import com.example.thewallet.search_fragments.SearchSection
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayout.OnTabSelectedListener
import kotlinx.android.synthetic.main.fragment_statistics.view.tabs


class SearchFragment : Fragment() {




    @SuppressLint("ResourceAsColor")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        val inf=inflater.inflate(R.layout.fragment_statistics, container, false)

        requireActivity().supportFragmentManager.beginTransaction().replace(R.id.SearchNavHost,SearchSection()).commit()
        when (this.resources.configuration?.uiMode?.and(Configuration.UI_MODE_NIGHT_MASK)) {
            Configuration.UI_MODE_NIGHT_YES -> {

                inf.tabs.setTabTextColors(Color.GRAY, Color.WHITE);
            }

            Configuration.UI_MODE_NIGHT_NO -> {

                inf.tabs.setTabTextColors(Color.GRAY, Color.BLACK);
            }

        }

        inf.tabs.addOnTabSelectedListener(object : OnTabSelectedListener {
            @SuppressLint("CommitTransaction")
            override fun onTabSelected(tab: TabLayout.Tab) {
                if (tab.position==1){
                    requireActivity().supportFragmentManager.beginTransaction().replace(R.id.SearchNavHost,SearchExpense()).commit()
                }else{
                    requireActivity().supportFragmentManager.beginTransaction().replace(R.id.SearchNavHost,SearchSection()).commit()
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })

        return inf
    }




}