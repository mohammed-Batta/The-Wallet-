package com.example.thewallet.view_fragments

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.example.thewallet.R
import com.example.thewallet.activitys.LoginA
import com.example.thewallet.activitys.MainActivity
import com.example.thewallet.adapters.SectionAdapter
import com.example.thewallet.luxuries.SEC_BACK
import com.example.thewallet.luxuries.SEC_DES
import com.example.thewallet.luxuries.SEC_NAME
import kotlinx.android.synthetic.main.fragment_search_section.view.liner2_section_search
import kotlinx.android.synthetic.main.fragment_search_section.view.nodataLottie
import kotlinx.android.synthetic.main.fragment_view_section.view.cardView2
import kotlinx.android.synthetic.main.fragment_view_section.view.et_Search_name_Sec
import kotlinx.android.synthetic.main.fragment_view_section.view.iv_backFromView_edit_Sec
import kotlinx.android.synthetic.main.fragment_view_section.view.liner2
import kotlinx.android.synthetic.main.fragment_view_section.view.listView_in_ViewAndEditSecScreen
import kotlinx.android.synthetic.main.fragment_view_section.view.nodataLottie_viewsec
import kotlinx.android.synthetic.main.fragment_view_section.view.tv_viewAndEditSec

class ViewSection : Fragment() {

    companion object {
        @JvmStatic
        fun bundleSection(name: String, description: String,back:Int) =
            ViewSection().apply {
                arguments = Bundle().apply {
                    putString(SEC_NAME, name)
                    putString(SEC_DES, description)
                    putInt(SEC_BACK, back)
                }
            }
    }



    @SuppressLint("ResourceAsColor")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        val inf=inflater.inflate(R.layout.fragment_view_section, container, false)

        try {
            when (this.resources.configuration?.uiMode?.and(Configuration.UI_MODE_NIGHT_MASK)) {
                Configuration.UI_MODE_NIGHT_YES -> {
                    inf.tv_viewAndEditSec.setTextColor(Color.WHITE)
                }

                Configuration.UI_MODE_NIGHT_NO -> {
                    inf.tv_viewAndEditSec.setTextColor(Color.BLACK)
                }

            }
            if (LoginA.db.getSectionsCount()>0L){
                inf.liner2.visibility=View.VISIBLE
                inf.nodataLottie_viewsec.visibility=View.GONE
                inf.liner2.setBackgroundColor(R.color.Dark)
            }

            inf.iv_backFromView_edit_Sec.setOnClickListener {
                findNavController().popBackStack(R.id.homeFragment,false)
            }
            inf.listView_in_ViewAndEditSecScreen.adapter = SectionAdapter(requireContext(), LoginA.db.getAllSections(),this,
                inf.nodataLottie_viewsec,inf.liner2,R.id.action_viewSection_to_editSection,R.id.viewSection)

            val textWatcher = object : TextWatcher {
                override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                }

                override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                    try {
                        val filter = LoginA.db.searchForSectionsTitle(p0.toString())
                        inf.listView_in_ViewAndEditSecScreen.adapter = SectionAdapter(requireContext(), filter,
                            this@ViewSection,inf.nodataLottie_viewsec,inf.liner2,R.id.action_viewSection_to_editSection,R.id.viewSection)
                    }catch (e:Exception){
                        Toast.makeText(requireContext(), e.message, Toast.LENGTH_SHORT).show()
                    }
                }

                override fun afterTextChanged(p0: Editable?) {
                }
            }
            inf.et_Search_name_Sec.addTextChangedListener(textWatcher)

        }catch (e:Exception){
            Toast.makeText(requireContext(), e.message, Toast.LENGTH_LONG).show()}

        return inf
    }


    override fun onAttach(context: Context) {
        (activity as MainActivity).hideBottomNavigation()
        super.onAttach(context)
    }


    override fun onResume() {
        super.onResume()
        (activity as MainActivity).hideBottomNavigation()
    }

    override fun onDetach() {
        super.onDetach()
        (activity as MainActivity).showBottomNavigation()
    }

}