package com.example.thewallet.activitys

import android.annotation.SuppressLint
import android.annotation.TargetApi
import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.Toast
import androidx.annotation.DrawableRes
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.core.os.postDelayed
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.NavigationUI
import com.example.thewallet.luxuries.LocaleHelper
import com.example.thewallet.R
import com.example.thewallet.luxuries.shared_settings_file_name
import com.example.thewallet.luxuries.shared_settings_language_key
import com.example.thewallet.luxuries.shared_settings_mode_dark
import com.example.thewallet.luxuries.shared_settings_mode_key
import com.example.thewallet.luxuries.shared_settings_mode_light
import kotlinx.android.synthetic.main.activity_main.bottomNavView
import kotlinx.android.synthetic.main.activity_main.cons

class MainActivity : AppCompatActivity() {

    private lateinit var navController: NavController
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sharedPreferences = getSharedPreferences(shared_settings_file_name, Context.MODE_PRIVATE)
       val mode= sharedP(sharedPreferences)
        window.setBackgroundDrawableResource(R.drawable.color_top)
        setContentView(R.layout.activity_main)
        try {
            if (mode== shared_settings_mode_dark) {
                cons.setBackgroundColor(getColor(R.color.DarkBar))
            }else{
                cons.setBackgroundColor(getColor(R.color.WhiteBar))

            }


            setupViews()
        }catch (e:Exception){
                    Toast.makeText(this, e.message, Toast.LENGTH_LONG).show()
                }
    }
    private fun setupViews() {
       val navHostFragment= supportFragmentManager.findFragmentById(R.id.fragNavHost) as NavHostFragment
        navController = navHostFragment.navController
        NavigationUI.setupWithNavController(bottomNavView, navController)

    }
    fun showBottomNavigation() {
        bottomNavView.visibility = View.VISIBLE
    }

    fun hideBottomNavigation() {
        bottomNavView.visibility = View.GONE
    }
    private var backPressedOnce = false

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {

        if (navController.graph.startDestinationId == navController.currentDestination?.id) {
            if (backPressedOnce) {
                return super.onKeyDown(keyCode, event)
            }
            backPressedOnce = true
            Handler(Looper.myLooper()!!).postDelayed(1000) {
                backPressedOnce = false
            }
        }
        return super.onKeyDown(keyCode, event)
    }
    private fun sharedP(shared: SharedPreferences):String{

            var mode: String? = null
            val language = shared.getString(
                shared_settings_language_key,
                applicationContext.resources.configuration.locale.language.toString()
            )

            LocaleHelper.setLocale(this, language!!)
            when (applicationContext.resources.configuration?.uiMode?.and(Configuration.UI_MODE_NIGHT_MASK)) {
                Configuration.UI_MODE_NIGHT_YES -> {
                    mode = shared.getString(shared_settings_mode_key, shared_settings_mode_dark)
                }

                Configuration.UI_MODE_NIGHT_NO -> {
                    mode = shared.getString(shared_settings_mode_key, shared_settings_mode_light)
                }
            }
            if (mode == shared_settings_mode_dark) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            } else if (mode == shared_settings_mode_light) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }

        return mode!!
    }




}
