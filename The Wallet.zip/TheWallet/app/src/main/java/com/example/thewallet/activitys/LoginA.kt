package com.example.thewallet.activitys

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.example.thewallet.DataBase
import com.example.thewallet.luxuries.LocaleHelper
import com.example.thewallet.R
import com.example.thewallet.luxuries.shared_settings_Biometrics_disabled
import com.example.thewallet.luxuries.shared_settings_Biometrics_key
import com.example.thewallet.luxuries.shared_settings_LockScreen_answer
import com.example.thewallet.luxuries.shared_settings_LockScreen_password
import com.example.thewallet.luxuries.shared_settings_LockScreen_privateQ
import com.example.thewallet.luxuries.shared_settings_file_name
import com.example.thewallet.luxuries.shared_settings_language_key
import com.example.thewallet.luxuries.shared_settings_mode_dark
import com.example.thewallet.luxuries.shared_settings_mode_key
import com.example.thewallet.luxuries.shared_settings_mode_light
import kotlinx.android.synthetic.main.activity_login.LinearLayout_forgetPassword
import kotlinx.android.synthetic.main.activity_login.btn_login
import kotlinx.android.synthetic.main.activity_login.con_answer
import kotlinx.android.synthetic.main.activity_login.con_password
import kotlinx.android.synthetic.main.activity_login.et_answer_login
import kotlinx.android.synthetic.main.activity_login.et_password_login
import kotlinx.android.synthetic.main.activity_login.fingerLottie
import kotlinx.android.synthetic.main.activity_login.forgetPassLogin
import kotlinx.android.synthetic.main.activity_login.iv_backFromForgetPasswor_login
import kotlinx.android.synthetic.main.activity_login.mainLyout
import kotlinx.android.synthetic.main.activity_login.privateQ_login
import kotlinx.android.synthetic.main.activity_login.tv_password_login
import kotlinx.android.synthetic.main.activity_main.cons
import java.util.concurrent.Executor

class LoginA : AppCompatActivity() {
    private lateinit var executor: Executor
    private lateinit var biometricPrompt: BiometricPrompt
    private lateinit var promptInfo: BiometricPrompt.PromptInfo
    companion object{
        var flag=0
        @SuppressLint("StaticFieldLeak")
        lateinit var db: DataBase
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        installSplashScreen()
        val sharedPreferences = getSharedPreferences(shared_settings_file_name, Context.MODE_PRIVATE)
       val mode= sharedP(sharedPreferences)
        window.setBackgroundDrawableResource(R.drawable.color_top)
        setContentView(R.layout.activity_login)
        if (mode== shared_settings_mode_dark) {
            mainLyout.setBackgroundColor(getColor(R.color.DarkBar))
        }else{
            mainLyout.setBackgroundColor(getColor(R.color.WhiteBar))

        }
        db = DataBase(this)
        val password = sharedPreferences.getString(shared_settings_LockScreen_password, null)
        val privateQ = sharedPreferences.getString(shared_settings_LockScreen_privateQ, null)
        val answer = sharedPreferences.getString(shared_settings_LockScreen_answer, null)
        val isThereFingerPrint = sharedPreferences.getString(shared_settings_Biometrics_key, shared_settings_Biometrics_disabled)
        if (flag ==0) {
            if ((password == null && privateQ == null && answer == null) && isThereFingerPrint == shared_settings_Biometrics_disabled) {
                finishAffinity()
                startActivity(Intent(this, MainActivity::class.java))
                flag = 1
            } else if (password == null && privateQ == null && answer == null) {
                confirmBiometricsWithOutPassword()
                mainLyout.visibility=View.INVISIBLE

            }else if ((password != null && privateQ != null && answer != null)&& isThereFingerPrint == shared_settings_Biometrics_disabled) {
                fingerLottie.visibility=View.GONE
            }else if (password != null && privateQ != null && answer != null){
                fingerLottie.visibility=View.VISIBLE

            }
            fingerLottie.setOnClickListener {
                confirmBiometrics()
            }
            forgetPassLogin.setOnClickListener {
                privateQ_login.text = privateQ
                showForgetPassword()
                goneSetPassword()
            }
            iv_backFromForgetPasswor_login.setOnClickListener {
                goneForgetPassword()
                showSetPassword()
            }

            btn_login.setOnClickListener {
                val pass = et_password_login.text.toString().trim()
                val ans = et_answer_login.text.toString().trim()
                if (pass.isNotEmpty() && pass == password) {
                    finishAffinity()
                    startActivity(Intent(this, MainActivity::class.java))
                    flag =1
                } else if (ans.isNotEmpty()&&ans==answer){
                    finishAffinity()
                    startActivity(Intent(this, MainActivity::class.java))
                    flag =1
                } else { Toast.makeText(this, resources.getString(R.string.incorrect), Toast.LENGTH_SHORT).show() }

            }
        }else{
            finishAffinity()
            startActivity(Intent(this, MainActivity::class.java))
        }


        }

    private fun confirmBiometricsWithOutPassword() {
        executor = ContextCompat.getMainExecutor(this@LoginA)
        biometricPrompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                finishAffinity()
                startActivity(Intent(this@LoginA, MainActivity::class.java))
                flag =1
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                super.onAuthenticationError(errorCode, errString)
                Toast.makeText(this@LoginA, errString.toString(), Toast.LENGTH_SHORT).show()
                finishAffinity()
            }

            override fun onAuthenticationFailed() {
                super.onAuthenticationFailed()
                Toast.makeText(this@LoginA, resources.getString(R.string.toastError), Toast.LENGTH_SHORT).show()
            }
        })

        promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle(resources.getString(R.string.Biometricconfirmation))
            .setSubtitle(resources.getString(R.string.desforBiometric))
            .setNegativeButtonText(resources.getString(R.string.btn_cancel))
            .build()
        biometricPrompt.authenticate(promptInfo)
    }

    private fun showForgetPassword() {
        LinearLayout_forgetPassword.visibility=View.VISIBLE
        privateQ_login.visibility=View.VISIBLE
        con_answer.visibility=View.VISIBLE
    }
    private fun goneForgetPassword() {
        LinearLayout_forgetPassword.visibility=View.GONE
        privateQ_login.visibility=View.GONE
        con_answer.visibility=View.GONE

    }
    private fun goneSetPassword() {
        con_password.visibility=View.GONE
        forgetPassLogin.visibility=View.GONE
        et_password_login.visibility=View.GONE
        tv_password_login.visibility=View.GONE

    }
    private fun showSetPassword() {
        con_password.visibility=View.VISIBLE
        et_password_login.visibility=View.VISIBLE
        forgetPassLogin.visibility=View.VISIBLE
        tv_password_login.visibility=View.VISIBLE
    }



    private fun confirmBiometrics() {
        executor = ContextCompat.getMainExecutor(this@LoginA)
        biometricPrompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                finishAffinity()
                startActivity(Intent(this@LoginA, MainActivity::class.java))
                flag =1
            }

            override fun onAuthenticationFailed() {
                super.onAuthenticationFailed()
                Toast.makeText(this@LoginA, resources.getString(R.string.toastError), Toast.LENGTH_SHORT).show()
            }
        })

        promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle(resources.getString(R.string.Biometricconfirmation))
            .setSubtitle(resources.getString(R.string.desforBiometric))
            .setNegativeButtonText(resources.getString(R.string.btn_cancel))
            .build()
        biometricPrompt.authenticate(promptInfo)
    }
    private fun sharedP(shared: SharedPreferences):String{
            var mode: String? = null
            val language = shared.getString(
                shared_settings_language_key,
                applicationContext.resources.configuration.locale.language.toString()
            )

        LocaleHelper.setLocale(this, language!!)
            when (applicationContext.resources.configuration?.uiMode?.and(Configuration.UI_MODE_NIGHT_MASK)) {
                Configuration.UI_MODE_NIGHT_YES -> {
                    mode = shared.getString(shared_settings_mode_key, shared_settings_mode_dark)
                }

                Configuration.UI_MODE_NIGHT_NO -> {
                    mode = shared.getString(shared_settings_mode_key, shared_settings_mode_light)
                }
            }
            if (mode == shared_settings_mode_dark) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            } else if (mode == shared_settings_mode_light) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }

        return mode!!

    }


}