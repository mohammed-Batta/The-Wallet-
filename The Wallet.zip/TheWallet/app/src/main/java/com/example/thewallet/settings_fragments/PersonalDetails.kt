package com.example.thewallet.settings_fragments

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.graphics.drawable.toBitmap
import androidx.navigation.fragment.findNavController
import com.example.thewallet.R
import com.example.thewallet.luxuries.Utils
import com.example.thewallet.activitys.MainActivity
import com.example.thewallet.luxuries.readImageFromInStorge
import com.example.thewallet.luxuries.shared_settings_PersonalDetails_image
import com.example.thewallet.luxuries.shared_settings_PersonalDetails_name
import com.example.thewallet.luxuries.shared_settings_file_name
import kotlinx.android.synthetic.main.fragment_personal_details.image_edit_account
import kotlinx.android.synthetic.main.fragment_personal_details.view.btn_reset_personal
import kotlinx.android.synthetic.main.fragment_personal_details.view.btn_save_personal
import kotlinx.android.synthetic.main.fragment_personal_details.view.et_SetName
import kotlinx.android.synthetic.main.fragment_personal_details.view.image_edit_account
import kotlinx.android.synthetic.main.fragment_personal_details.view.iv_backFromEditPersonal
import kotlinx.android.synthetic.main.fragment_personal_details.view.resetImage_Account
import kotlinx.android.synthetic.main.fragment_personal_details.view.tv_edit_personal
import java.io.File
import java.io.FileOutputStream

class PersonalDetails : Fragment() {
    lateinit var shared:SharedPreferences
    @SuppressLint("SuspiciousIndentation", "CommitPrefEdits")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
      val inf=inflater.inflate(R.layout.fragment_personal_details, container, false)
        try {
            val file = File(requireContext().filesDir, shared_settings_PersonalDetails_image)
            if (file.exists()){
                inf.resetImage_Account.visibility= VISIBLE
            }
            inf.resetImage_Account.setOnClickListener {
                inf.image_edit_account.setImageResource(R.drawable.sod)
                file.delete()
                inf.resetImage_Account.visibility= GONE
            }

             shared = requireContext().getSharedPreferences(shared_settings_file_name, Context.MODE_PRIVATE)
            when (requireActivity().resources.configuration?.uiMode?.and(Configuration.UI_MODE_NIGHT_MASK)) {
                Configuration.UI_MODE_NIGHT_YES -> {
                    inf.tv_edit_personal.setTextColor(Color.WHITE)
                }

                Configuration.UI_MODE_NIGHT_NO -> {
                    inf.tv_edit_personal.setTextColor(Color.BLACK)
                }
            }
            val nam = shared.getString(shared_settings_PersonalDetails_name, "")
            if (nam != "") {
                inf.btn_reset_personal.visibility = VISIBLE
                inf.et_SetName.setText(nam)
            }

                try{
                    val file1 = File(requireContext().filesDir, shared_settings_PersonalDetails_image)
                    if (file1.exists()){
                        readImageFromInStorge(requireContext(),inf.image_edit_account)
                    }
                }catch (e:Exception){
                    Toast.makeText(requireContext(), e.message, Toast.LENGTH_LONG).show()}

            inf.btn_reset_personal.setOnClickListener {
                shared.edit().remove(shared_settings_PersonalDetails_name).apply()
                inf.et_SetName.text?.clear()
                val file2 = File(requireContext().filesDir, shared_settings_PersonalDetails_image)
                if (file2.exists()){
                    file2.delete()
                    inf.image_edit_account.setImageResource(R.drawable.sod)
                }
                inf.btn_reset_personal.visibility = View.GONE
                inf.resetImage_Account.visibility = View.GONE
            }

            inf.iv_backFromEditPersonal.setOnClickListener {
                findNavController().popBackStack(R.id.profileFragment, false)
            }

            inf.btn_save_personal.setOnClickListener {
                val name = inf.et_SetName.text.toString().trim()
                if (name.isNotEmpty()) {
                    val edit = shared.edit()
                    edit.putString(shared_settings_PersonalDetails_name, name).apply()
                    Toast.makeText(requireContext(), resources.getString(R.string.toastSaved), Toast.LENGTH_SHORT).show()
                    inf.btn_reset_personal.visibility = VISIBLE
                }
            }
            inf.image_edit_account.setOnClickListener {
                val photoPicker = Intent(Intent.ACTION_PICK)
                photoPicker.type = "image/*"
                startActivityForResult(photoPicker, 5555)
            }

        }catch (e:Exception){
            Toast.makeText(requireContext(), e.message, Toast.LENGTH_LONG).show()
        }
        return inf
    }
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestcode: Int, resultcode: Int, data: Intent?) {
        super.onActivityResult(requestcode, resultcode, data)
        if (resultcode == Activity.RESULT_OK) {
            if (requestcode == 5555&&data !=null) {
                val u= data.data!!
                image_edit_account.setImageURI(u)
                val bitmap=(image_edit_account.drawable as BitmapDrawable).toBitmap()
                    val context = requireContext().applicationContext
                    val directory = context.filesDir
                    val file = File(directory, shared_settings_PersonalDetails_image)
                    val outputStream = FileOutputStream(file)
                    outputStream.write(Utils.getBytes(bitmap))
                    outputStream.close()
            }
        }
    }

    override fun onAttach(context: Context) {
        (activity as MainActivity).hideBottomNavigation()
        super.onAttach(context)
    }

    override fun onDetach() {
        super.onDetach()
        (activity as MainActivity).showBottomNavigation()
    }


}