package com.example.thewallet.adapters

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.navOptions
import com.example.thewallet.activitys.LoginA.Companion.db
import com.example.thewallet.R
import com.example.thewallet.view_fragments.ViewExpense.Companion.bundleExpense
import com.example.thewallet.dataclasss.Expenses
import com.example.thewallet.luxuries.ForDataCurrency
import com.example.thewallet.luxuries.currency_key
import com.example.thewallet.luxuries.shared_settings_file_name
import com.example.thewallet.luxuries.shared_wallet_balance
import com.example.thewallet.luxuries.shared_wallet_expenses
import com.example.thewallet.luxuries.shared_wallet_file_name
import kotlinx.android.synthetic.main.delete_exp_dialog.view.btn_cancel_delete_Exp_dialog
import kotlinx.android.synthetic.main.delete_exp_dialog.view.btn_cancel_delete_Exp_with_two_options_dialog
import kotlinx.android.synthetic.main.delete_exp_dialog.view.btn_done_delete_Exp_dialog
import kotlinx.android.synthetic.main.delete_exp_dialog.view.btn_done_delete_Exp_with_two_options_dialog
import kotlinx.android.synthetic.main.delete_exp_dialog.view.linearLayout
import kotlinx.android.synthetic.main.delete_exp_dialog.view.linearLayout2
import kotlinx.android.synthetic.main.delete_exp_dialog.view.delete_the_expense_without_returning_the_amount_to_the_wallet
import kotlinx.android.synthetic.main.delete_exp_dialog.view.delete_the_expense_and_return_the_amount_to_the_wallet
import kotlinx.android.synthetic.main.delete_exp_dialog.view.radioGroup
import kotlinx.android.synthetic.main.delete_exp_dialog.view.tv_areYouSure
import kotlinx.android.synthetic.main.exp_item.view.Exp_Date
import kotlinx.android.synthetic.main.exp_item.view.Exp_btn_delete
import kotlinx.android.synthetic.main.exp_item.view.Exp_btn_edit
import kotlinx.android.synthetic.main.exp_item.view.Exp_currency
import kotlinx.android.synthetic.main.exp_item.view.Exp_description
import kotlinx.android.synthetic.main.exp_item.view.Exp_price
import kotlinx.android.synthetic.main.exp_item.view.Exp_section_name
import kotlinx.android.synthetic.main.exp_item.view.Exp_title

class ExpenseAdapter(private val c: Context, private val arrayList: ArrayList<Expenses>, private val fragment: Fragment,private val action:Int,private val back:Int,private val lottie:View,private val card:View,private val filter:View):
    ArrayAdapter<Expenses>(c, android.R.layout.simple_dropdown_item_1line,arrayList ) {

    @SuppressLint("ViewHolder", "InflateParams", "SetTextI18n")
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val inf = LayoutInflater.from(c).inflate(R.layout.exp_item, null)
        try {

            inf.Exp_title.text = arrayList[position].name
            inf.Exp_section_name.text = arrayList[position].sectionname
            inf.Exp_description.text = arrayList[position].description
            inf.Exp_Date.text = "${arrayList[position].day}-${arrayList[position].month}-${arrayList[position].year}"
            inf.Exp_price.text = arrayList[position].price.toString()
            val sharedPreferences=c.getSharedPreferences(shared_settings_file_name,Context.MODE_PRIVATE)
            val currency=sharedPreferences.getInt(currency_key,0)
            inf.Exp_currency.text = ForDataCurrency[currency]


            inf.Exp_btn_edit.setOnClickListener {
                val arguments=  bundleExpense(arrayList[position].id.toString()
                    ,arrayList[position].name
                    ,arrayList[position].description
                    ,arrayList[position].price,arrayList[position].sectionname
                    ,arrayList[position].day,arrayList[position].month
                    ,arrayList[position].year,back).arguments
                fragment.findNavController().navigate(action,arguments,
                    navOptions {
                        anim {
                            enter = android.R.animator.fade_in
                            exit = android.R.animator.fade_out } })

            }
            inf.Exp_btn_delete.setOnClickListener {
                showDeleteDialog(position)
            }
        }catch (e:Exception){
            Toast.makeText(c, e.message, Toast.LENGTH_LONG).show()
        }

        return inf
    }

    private fun showDeleteDialog(position: Int) {
        val view = LayoutInflater.from(c).inflate(R.layout.delete_exp_dialog, null)
        val alertDialog = AlertDialog.Builder(c, R.style.CustomAlertDialog).create()
        alertDialog.setCanceledOnTouchOutside(false)
        alertDialog.setView(view)
        view.btn_done_delete_Exp_dialog.setOnClickListener {
            view.tv_areYouSure.visibility=View.GONE
            view.linearLayout.visibility=View.GONE
            view.radioGroup.visibility=View.VISIBLE
            view.linearLayout2.visibility=View.VISIBLE
        }
        view.btn_done_delete_Exp_with_two_options_dialog.setOnClickListener {
            val sharedPreferences=c.getSharedPreferences(shared_wallet_file_name,Context.MODE_PRIVATE)
            val oldBalance= sharedPreferences.getFloat(shared_wallet_balance,0.0f)
            val oldExpenses= sharedPreferences.getFloat(shared_wallet_expenses,0.0f)
            if (view.delete_the_expense_and_return_the_amount_to_the_wallet.isChecked){
                val newBalance=oldBalance+arrayList[position].price
                val newExpenses=oldExpenses-arrayList[position].price
                sharedPreferences.edit().putFloat(shared_wallet_balance,newBalance).apply()
                sharedPreferences.edit().putFloat(shared_wallet_expenses,newExpenses).apply()
                val delete=db.clearExpense(arrayList[position].id.toString())
                if (delete){
                    Toast.makeText(c, c.resources.getString(R.string.toastDeleteExp), Toast.LENGTH_SHORT).show()
                    arrayList.removeAt(position)
                    notifyDataSetChanged()
                    notifyDataSetInvalidated()
                    alertDialog.dismiss()
                    if (arrayList.isEmpty()){
                        card.visibility=View.GONE
                        lottie.visibility=View.VISIBLE
                        filter.isEnabled=false
                    }
                }else{
                    Toast.makeText(c, c.resources.getString(R.string.toastError), Toast.LENGTH_SHORT).show()
                }

            }else if (view.delete_the_expense_without_returning_the_amount_to_the_wallet.isChecked){
                val delete=db.clearExpense(arrayList[position].id.toString())
                if (delete){
                    Toast.makeText(c, c.resources.getString(R.string.toastDeleteExp), Toast.LENGTH_SHORT).show()
                    arrayList.removeAt(position)
                    notifyDataSetChanged()
                    notifyDataSetInvalidated()
                    alertDialog.dismiss()
                    if (arrayList.isEmpty()){
                        card.visibility=View.GONE
                        lottie.visibility=View.VISIBLE
                        filter.isEnabled=false
                    }
                }else{
                    Toast.makeText(c, c.resources.getString(R.string.toastError), Toast.LENGTH_SHORT).show()
                }
            }else{

                Toast.makeText(c, c.resources.getString(R.string.plz_pick), Toast.LENGTH_SHORT).show()
            }
        }

        view.btn_cancel_delete_Exp_dialog.setOnClickListener {
            alertDialog.dismiss()
        }

        view.btn_cancel_delete_Exp_with_two_options_dialog.setOnClickListener {
            alertDialog.dismiss()
        }
        alertDialog.show()
    }


}