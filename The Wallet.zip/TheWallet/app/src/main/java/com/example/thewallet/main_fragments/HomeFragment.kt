package com.example.thewallet.main_fragments

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import androidx.navigation.navOptions
import com.example.thewallet.activitys.LoginA.Companion.db
import com.example.thewallet.R
import com.example.thewallet.luxuries.ForDataCurrency
import com.example.thewallet.luxuries.currency_key
import com.example.thewallet.luxuries.shared_settings_file_name
import com.example.thewallet.luxuries.shared_wallet_additions
import com.example.thewallet.luxuries.shared_wallet_balance
import com.example.thewallet.luxuries.shared_wallet_expenses
import com.example.thewallet.luxuries.shared_wallet_file_name
import kotlinx.android.synthetic.main.fragment_home.view.AddExpRelative
import kotlinx.android.synthetic.main.fragment_home.view.AddSecRelative
import kotlinx.android.synthetic.main.fragment_home.view.Additions_currency
import kotlinx.android.synthetic.main.fragment_home.view.EditExpRelative
import kotlinx.android.synthetic.main.fragment_home.view.EditSecRelative
import kotlinx.android.synthetic.main.fragment_home.view.Expenses_currency
import kotlinx.android.synthetic.main.fragment_home.view.btnTheWallet
import kotlinx.android.synthetic.main.fragment_home.view.tv_Additions
import kotlinx.android.synthetic.main.fragment_home.view.tv_Expenses
import kotlinx.android.synthetic.main.fragment_home.view.tv_TheBalance
import kotlinx.android.synthetic.main.fragment_home.view.tv_currencyWallet

class HomeFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val inf = inflater.inflate(R.layout.fragment_home, container, false)

        when (this.resources.configuration?.uiMode?.and(Configuration.UI_MODE_NIGHT_MASK)) {
            Configuration.UI_MODE_NIGHT_YES -> {
                inf.tv_Expenses.setTextColor(Color.WHITE)
                inf.tv_Additions.setTextColor(Color.WHITE)
                inf.Additions_currency.setTextColor(Color.WHITE)
                inf.Expenses_currency.setTextColor(Color.WHITE)
            }

            Configuration.UI_MODE_NIGHT_NO -> {
                inf.tv_Expenses.setTextColor(Color.BLACK)
                inf.tv_Additions.setTextColor(Color.BLACK)
                inf.Additions_currency.setTextColor(Color.BLACK)
                inf.Expenses_currency.setTextColor(Color.BLACK)
            }

        }
        val sharedPreferences=requireContext().getSharedPreferences(shared_wallet_file_name,Context.MODE_PRIVATE)

        val sharedPreferences2=requireContext().getSharedPreferences(shared_settings_file_name,Context.MODE_PRIVATE)
        val currency=sharedPreferences2.getInt(currency_key,0)
        inf.Additions_currency.text = ForDataCurrency[currency]
        inf.Expenses_currency.text = ForDataCurrency[currency]
        inf.tv_currencyWallet.text = ForDataCurrency[currency]

        val showBalance= sharedPreferences.getFloat(shared_wallet_balance,0.0f)
        val additions= sharedPreferences.getFloat(shared_wallet_additions,0.0f)
        val expenses= sharedPreferences.getFloat(shared_wallet_expenses,0.0f)
        inf.tv_TheBalance.text = "$showBalance"
        inf.tv_Expenses.text = "$expenses"
        inf.tv_Additions.text = "$additions"
        inf.AddExpRelative.setOnClickListener {
            try{
                if (db.getSectionsCount()>0L) {
                    findNavController().navigate(R.id.action_homeFragment_to_addExp, null,
                        navOptions {
                            anim {
                                enter = android.R.animator.fade_in
                                exit = android.R.animator.fade_out
                            }
                        })
                }else{
                    Toast.makeText(requireContext(), resources.getString(R.string.toastYouMustEnterSectionFirst), Toast.LENGTH_SHORT).show()
                }
            }catch (e:Exception){
                Toast.makeText(requireContext(), e.message, Toast.LENGTH_SHORT).show()}

        }
        inf.AddSecRelative.setOnClickListener {

            findNavController().navigate(R.id.action_homeFragment_to_addSec, null,
                navOptions {
                    anim {
                        enter = android.R.animator.fade_in
                        exit = android.R.animator.fade_out
                    }
                })
        }
        inf.EditExpRelative.setOnClickListener {
            if (db.getExpensesCount()>0L) {
            findNavController().navigate(R.id.action_homeFragment_to_viewExpAndEdit, null,
                navOptions {
                    anim {
                        enter = android.R.animator.fade_in
                        exit = android.R.animator.fade_out
                    }
                })
            }else{
                Toast.makeText(requireContext(), resources.getString(R.string.toastYouMustEnterExpFirst), Toast.LENGTH_SHORT).show()
            }
        }
        inf.EditSecRelative.setOnClickListener {
            if (db.getSectionsCount()>0L) {
            findNavController().navigate(R.id.action_homeFragment_to_viewSection, null,
                navOptions {
                    anim {
                        enter = android.R.animator.fade_in
                        exit = android.R.animator.fade_out
                    }
                })
            }else{
                Toast.makeText(requireContext(), resources.getString(R.string.toastYouMustEnterSectionFirst), Toast.LENGTH_SHORT).show()
            }
        }

        inf.btnTheWallet.setOnClickListener {
            findNavController().navigate(R.id.action_homeFragment_to_theWallet, null,
                navOptions {
                    anim {
                        enter = android.R.animator.fade_in
                        exit = android.R.animator.fade_out
                    }
                })
        }


        return inf
    }

}