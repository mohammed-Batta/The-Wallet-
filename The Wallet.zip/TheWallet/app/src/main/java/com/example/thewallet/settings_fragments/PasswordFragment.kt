package com.example.thewallet.settings_fragments

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.thewallet.R
import com.example.thewallet.activitys.MainActivity
import com.example.thewallet.luxuries.shared_settings_LockScreen_answer
import com.example.thewallet.luxuries.shared_settings_LockScreen_password
import com.example.thewallet.luxuries.shared_settings_LockScreen_privateQ
import com.example.thewallet.luxuries.shared_settings_file_name
import kotlinx.android.synthetic.main.dilog_disable.view.btn_cancel_disable_dialog
import kotlinx.android.synthetic.main.dilog_disable.view.btn_done_disable_dialog
import kotlinx.android.synthetic.main.fragment_password.view.btn_Disable_password
import kotlinx.android.synthetic.main.fragment_password.view.btn_save_password
import kotlinx.android.synthetic.main.fragment_password.view.et_SetAnswer
import kotlinx.android.synthetic.main.fragment_password.view.et_SetPassword
import kotlinx.android.synthetic.main.fragment_password.view.et_SetPrivateQ
import kotlinx.android.synthetic.main.fragment_password.view.iv_backFromSetPass
import kotlinx.android.synthetic.main.fragment_password.view.tv_passwordUp


class PasswordFragment : Fragment() {

    @SuppressLint("CommitPrefEdits", "SuspiciousIndentation", "InflateParams")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val inf=inflater.inflate(R.layout.fragment_password, container, false)
        val passShared=requireActivity().getSharedPreferences(shared_settings_file_name,Context.MODE_PRIVATE)
       val password= passShared.getString(shared_settings_LockScreen_password,null)
       val privateQ= passShared.getString(shared_settings_LockScreen_privateQ,null)
       val answer= passShared.getString(shared_settings_LockScreen_answer,null)
        if (password!=null&&privateQ!=null&&answer!=null){
            inf.btn_Disable_password.visibility=View.VISIBLE
            inf.et_SetPassword.setText(password)
            inf.et_SetPrivateQ.setText(privateQ)
            inf.et_SetAnswer.setText(answer)
        }
        inf.btn_Disable_password.setOnClickListener {
            val view=LayoutInflater.from(requireContext()).inflate(R.layout.dilog_disable,null)
            val alertDialog=AlertDialog.Builder(requireContext(),R.style.CustomAlertDialog).create()
            alertDialog.setCanceledOnTouchOutside(false)
            alertDialog.setView(view)
            alertDialog.setCanceledOnTouchOutside(false)
            view.btn_done_disable_dialog.setOnClickListener {
                disablePassword(inf,alertDialog,passShared)

            }
            view.btn_cancel_disable_dialog.setOnClickListener {
                alertDialog.dismiss()
            }
            alertDialog.show()
        }

        when (requireActivity().resources.configuration?.uiMode?.and(Configuration.UI_MODE_NIGHT_MASK)) {
            Configuration.UI_MODE_NIGHT_YES -> {
                inf.tv_passwordUp.setTextColor(Color.WHITE)
            }

            Configuration.UI_MODE_NIGHT_NO -> {
                inf.tv_passwordUp.setTextColor(Color.BLACK)

            }


        }
        inf.btn_save_password.setOnClickListener {
            savePassword(inf,passShared)

        }

        inf.iv_backFromSetPass.setOnClickListener {
            findNavController().popBackStack(R.id.profileFragment,false)
        }

        return inf
    }

    private fun savePassword(inf:View, passShared:SharedPreferences){
        val password= inf.et_SetPassword.text.toString().trim()
        val privateQ= inf.et_SetPrivateQ.text.toString().trim()
        val answer= inf.et_SetAnswer.text.toString().trim()
        if (password.isNotEmpty()&&privateQ.isNotEmpty()&&answer.isNotEmpty()){
            val edit= passShared.edit()
            edit.putString(shared_settings_LockScreen_password,password)
            edit.putString(shared_settings_LockScreen_privateQ,privateQ)
            edit.putString(shared_settings_LockScreen_answer,answer)
                .apply()
            Toast.makeText(requireContext(), resources.getString(R.string.toastSaved), Toast.LENGTH_SHORT).show()
            findNavController().popBackStack(R.id.profileFragment,false)

        }else{
            Toast.makeText(requireContext(), resources.getString(R.string.fillet), Toast.LENGTH_SHORT).show()
        }
    }




    private fun disablePassword(inf:View,alertDialog: AlertDialog, passShared:SharedPreferences){
        val edit= passShared.edit()
        edit.remove(shared_settings_LockScreen_password)
        edit.remove(shared_settings_LockScreen_privateQ)
        edit.remove(shared_settings_LockScreen_answer)
            .apply()
        Toast.makeText(requireContext(),resources.getString(R.string.toastDibabled), Toast.LENGTH_SHORT).show()
        inf.et_SetPassword.text?.clear()
        inf.et_SetPrivateQ.text?.clear()
        inf.et_SetAnswer.text?.clear()
        alertDialog.dismiss()
        inf.btn_Disable_password.visibility=View.GONE
    }



    override fun onAttach(context: Context) {
        (activity as MainActivity).hideBottomNavigation()
        super.onAttach(context)
    }

    override fun onDetach() {
        super.onDetach()
        (activity as MainActivity).showBottomNavigation()
    }

}

