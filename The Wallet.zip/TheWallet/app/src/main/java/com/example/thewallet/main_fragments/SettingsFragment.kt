package com.example.thewallet.main_fragments

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatDelegate
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.navOptions
import com.example.thewallet.luxuries.LocaleHelper
import com.example.thewallet.R
import com.example.thewallet.activitys.MainActivity
import com.example.thewallet.luxuries.arrayCurrency
import com.example.thewallet.luxuries.currency_key
import com.example.thewallet.luxuries.readImageFromInStorge
import com.example.thewallet.luxuries.shared_settings_Biometrics_disabled
import com.example.thewallet.luxuries.shared_settings_Biometrics_enabled
import com.example.thewallet.luxuries.shared_settings_Biometrics_key
import com.example.thewallet.luxuries.shared_settings_LockScreen_answer
import com.example.thewallet.luxuries.shared_settings_LockScreen_password
import com.example.thewallet.luxuries.shared_settings_LockScreen_privateQ
import com.example.thewallet.luxuries.shared_settings_PersonalDetails_name
import com.example.thewallet.luxuries.shared_settings_file_name
import com.example.thewallet.luxuries.shared_settings_language_ar
import com.example.thewallet.luxuries.shared_settings_language_en
import com.example.thewallet.luxuries.shared_settings_language_key
import com.example.thewallet.luxuries.shared_settings_mode_dark
import com.example.thewallet.luxuries.shared_settings_mode_key
import com.example.thewallet.luxuries.shared_settings_mode_light
import kotlinx.android.synthetic.main.dialog_password.view.LinearLayout_forgetPassword_dialog
import kotlinx.android.synthetic.main.dialog_password.view.LinearLayout_password_dialog
import kotlinx.android.synthetic.main.dialog_password.view.btn_cancel_forget_password_dialog
import kotlinx.android.synthetic.main.dialog_password.view.btn_cancel_password_dialog
import kotlinx.android.synthetic.main.dialog_password.view.btn_done_forget_password_dialog
import kotlinx.android.synthetic.main.dialog_password.view.btn_done_password_dialog
import kotlinx.android.synthetic.main.dialog_password.view.et_ForgetPassword_dialog
import kotlinx.android.synthetic.main.dialog_password.view.et_SetPassword_dialog
import kotlinx.android.synthetic.main.dialog_password.view.iv_backFromForgetPassword_dilaog
import kotlinx.android.synthetic.main.dialog_password.view.tv_forget_password_Q_dialog
import kotlinx.android.synthetic.main.dialog_password.view.tv_forget_password_dialog
import kotlinx.android.synthetic.main.dialog_password.view.tv_forget_password_dialog_clicked
import kotlinx.android.synthetic.main.dialog_password.view.tv_password_dialog
import kotlinx.android.synthetic.main.dialog_reset_settings.view.btn_cancel_reset_settings_dialog
import kotlinx.android.synthetic.main.dialog_reset_settings.view.btn_done_reset_settings_dialog
import kotlinx.android.synthetic.main.dilog_language.view.btn_cancel_lan_dialog
import kotlinx.android.synthetic.main.dilog_language.view.btn_done_lan_dialog
import kotlinx.android.synthetic.main.dilog_language.view.rb_arabic
import kotlinx.android.synthetic.main.dilog_language.view.rb_english
import kotlinx.android.synthetic.main.dilog_language.view.tv_login
import kotlinx.android.synthetic.main.fragment_settings.view.darkModeSwitch
import kotlinx.android.synthetic.main.fragment_settings.view.enableFingerPrintSwitch
import kotlinx.android.synthetic.main.fragment_settings.view.profileCircleImageView
import kotlinx.android.synthetic.main.fragment_settings.view.show_profile
import kotlinx.android.synthetic.main.fragment_settings.view.tv_clearAppData
import kotlinx.android.synthetic.main.fragment_settings.view.tv_currencyPicker
import kotlinx.android.synthetic.main.fragment_settings.view.tv_languagePicker
import kotlinx.android.synthetic.main.fragment_settings.view.tv_settings
import kotlinx.android.synthetic.main.fragment_settings.view.tv_showName
import kotlinx.android.synthetic.main.fragment_settings.view.tv_password
import kotlinx.android.synthetic.main.show_currncy_dialog.view.btn_cancelCurrency
import kotlinx.android.synthetic.main.show_currncy_dialog.view.listOfCurrency
import java.io.File
import java.util.concurrent.Executor


class SettingsFragment : Fragment() {
    lateinit var shared:SharedPreferences
    private lateinit var executor: Executor
    private lateinit var biometricPrompt: BiometricPrompt
    private lateinit var promptInfo: BiometricPrompt.PromptInfo
    @SuppressLint("CommitPrefEdits", "WrongConstant")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val inf= inflater.inflate(R.layout.fragment_settings, container, false)
       try {


           when (this.resources.configuration?.uiMode?.and(Configuration.UI_MODE_NIGHT_MASK)) {
               Configuration.UI_MODE_NIGHT_YES -> {
                   inf.darkModeSwitch.isChecked = true
                   inf.darkModeSwitch.setTextColor(Color.WHITE)
                   inf.tv_showName.setTextColor(Color.WHITE)
                   inf.tv_settings.setTextColor(Color.WHITE)
                   inf.tv_languagePicker.setTextColor(Color.WHITE)
                   inf.tv_clearAppData.setTextColor(Color.WHITE)
                   inf.tv_password.setTextColor(Color.WHITE)
                   inf.enableFingerPrintSwitch.setTextColor(Color.WHITE)
                   inf.tv_currencyPicker.setTextColor(Color.WHITE)
               }

               Configuration.UI_MODE_NIGHT_NO -> {
                   inf.darkModeSwitch.isChecked = false
                   inf.darkModeSwitch.setTextColor(Color.BLACK)
                   inf.tv_showName.setTextColor(Color.BLACK)
                   inf.tv_settings.setTextColor(Color.BLACK)
                   inf.tv_languagePicker.setTextColor(Color.BLACK)
                   inf.tv_clearAppData.setTextColor(Color.BLACK)
                   inf.tv_password.setTextColor(Color.BLACK)
                   inf.enableFingerPrintSwitch.setTextColor(Color.BLACK)
                   inf.tv_currencyPicker.setTextColor(Color.BLACK)
               }

           }
           inf.tv_currencyPicker.setOnClickListener {
               showCurrencyDialog()
           }

            shared = requireActivity().getSharedPreferences(shared_settings_file_name, Context.MODE_PRIVATE)
           val isCheckedFinger=shared.getString(
               shared_settings_Biometrics_key,
               shared_settings_Biometrics_disabled
           )
           inf.enableFingerPrintSwitch.isChecked = isCheckedFinger== shared_settings_Biometrics_enabled

           val name = shared.getString(shared_settings_PersonalDetails_name,null)
           if (name != null) {
               inf.tv_showName.text = name
           }

           val file = File(requireContext().filesDir, "image.txt")
           if (file.exists()){
               readImageFromInStorge(requireContext(),inf.profileCircleImageView)
           }

           inf.tv_clearAppData.setOnClickListener {
               val view=LayoutInflater.from(requireContext()).inflate(R.layout.dialog_reset_settings,null)
               val alertDialog=AlertDialog.Builder(requireContext(),R.style.CustomAlertDialog).create()
               alertDialog.setCanceledOnTouchOutside(false)
               alertDialog.setView(view)
               view.btn_done_reset_settings_dialog.setOnClickListener {
                   try {
                       alertDialog.dismiss()
                       val isThereFingerprint = shared.getString(shared_settings_Biometrics_key, shared_settings_Biometrics_disabled)
                       val password = shared.getString(shared_settings_LockScreen_password, null)
                       val question = shared.getString(shared_settings_LockScreen_privateQ, null)
                       val answer = shared.getString(shared_settings_LockScreen_answer, null)
                       if (isThereFingerprint == shared_settings_Biometrics_enabled) {
                           confirmBiometrics(file, inf, password ,question,answer)
                       } else if (password != null && question != null && answer != null) {
                           resetSettings(password, question, answer, file, inf)
                       } else {
                           shared.edit().clear().apply()
                           if (file.exists()) {
                               file.delete()
                           }
                           inf.enableFingerPrintSwitch.isChecked = false

                           Toast.makeText(requireContext(), resources.getString(R.string.toastClearSettings), Toast.LENGTH_SHORT).show()
                           refresh()
                       }
                   }catch (e:Exception){
                       Toast.makeText(requireContext(), e.message, Toast.LENGTH_LONG).show()
                   }
               }
               view.btn_cancel_reset_settings_dialog.setOnClickListener {
                   alertDialog.dismiss()
               }
               alertDialog.show()
           }
           inf.tv_password.setOnClickListener {
               val password= shared.getString(shared_settings_LockScreen_password,null)
               val privateQ= shared.getString(shared_settings_LockScreen_privateQ,null)
               val answer= shared.getString(shared_settings_LockScreen_answer,null)
               if (password==null&&privateQ==null&&answer==null){
                   findNavController().navigate(R.id.action_profileFragment_to_passwordFragment, null,
                       navOptions {
                           anim {
                               enter = android.R.animator.fade_in
                               exit = android.R.animator.fade_out
                           }
                       })
               }else{
                   showPasswordDialog(password!!,privateQ!!,answer!!)
               }


           }

           inf.tv_languagePicker.setOnClickListener {
               try {

                   val layoutInflater = LayoutInflater.from(requireActivity())
                   val builder = AlertDialog.Builder(requireContext(), R.style.CustomAlertDialog).create()
                   val view = layoutInflater.inflate(R.layout.dilog_language, null)
                   view.rb_english.setTextColor(Color.WHITE)
                   view.rb_arabic.setTextColor(Color.WHITE)
                   view.tv_login.setTextColor(Color.WHITE)
                   builder.setView(view)
                   builder.setCanceledOnTouchOutside(false)
                   val shared = requireActivity().getSharedPreferences(shared_settings_file_name, Context.MODE_PRIVATE)
                   val language = shared.getString(shared_settings_language_key, requireContext().resources.configuration.locale.language.toString())
                   if (language == shared_settings_language_en) {
                       view.rb_english.isChecked = true
                   } else {
                       view.rb_arabic.isChecked = true
                   }

                   view.btn_done_lan_dialog.setOnClickListener {
                       try {
                           val sharedPreferences = requireActivity().getSharedPreferences(
                               shared_settings_file_name,
                               Context.MODE_PRIVATE
                           )


                           if (view.rb_english.isChecked) {
                               builder.dismiss()
                               LocaleHelper.setLocale(requireActivity(), shared_settings_language_en);
                               sharedPreferences.edit().putString(
                                   shared_settings_language_key,
                                   shared_settings_language_en
                               ).apply()
                               (activity as MainActivity).recreate()


                           } else if (view.rb_arabic.isChecked) {
                               builder.dismiss()
                               LocaleHelper.setLocale(requireActivity(), shared_settings_language_ar);
                               sharedPreferences.edit().putString(shared_settings_language_key, shared_settings_language_ar).apply()
                               (activity as MainActivity).recreate()

                           } else {
                               Toast.makeText(
                                   requireContext(),
                                   resources.getString(R.string.plz_pick),
                                   Toast.LENGTH_SHORT
                               ).show()
                           }
                       } catch (e: Exception) {
                           Toast.makeText(requireContext(), e.message, Toast.LENGTH_LONG).show()
                       }

                   }
                   view.btn_cancel_lan_dialog.setOnClickListener {
                       builder.dismiss()
                   }

                   builder.show()
               } catch (e: Exception) {
                   Toast.makeText(requireContext(), e.message, Toast.LENGTH_LONG).show()
               }


           }
           inf.enableFingerPrintSwitch.setOnClickListener {
               val sharedPreferences = requireActivity().getSharedPreferences(
                   shared_settings_file_name, Context.MODE_PRIVATE)
               val isenabled=sharedPreferences.getString(
                   shared_settings_Biometrics_key,
                   shared_settings_Biometrics_disabled
               )
               val biometricManager = BiometricManager.from(requireContext())
               val canAuthenticate = biometricManager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)
               if (isenabled== shared_settings_Biometrics_enabled){
                   inf.enableFingerPrintSwitch.isChecked=true
                   confirmBiometricsForSwitch(inf,sharedPreferences)
               }else{
                   when (canAuthenticate) {
                       BiometricManager.BIOMETRIC_SUCCESS -> {
                           Toast.makeText(requireContext(), resources.getString(R.string.toasFingerprintEnabled), Toast.LENGTH_LONG).show()
                           sharedPreferences.edit().putString(
                               shared_settings_Biometrics_key,
                               shared_settings_Biometrics_enabled
                           ).apply()
                       }
                       BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> {
                           Toast.makeText(requireContext(), resources.getString(R.string.toasFingerprintnoHard), Toast.LENGTH_LONG).show()
                           inf.enableFingerPrintSwitch.isChecked=false

                       }
                       BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> {
                           Toast.makeText(requireContext(), resources.getString(R.string.toasFingerprintunviHard), Toast.LENGTH_LONG).show()
                           inf.enableFingerPrintSwitch.isChecked=false

                       }
                       BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> {
                           Toast.makeText(requireContext(), resources.getString(R.string.toasFingerprintNONE_ENROLLED), Toast.LENGTH_LONG).show()
                           inf.enableFingerPrintSwitch.isChecked=false

                       }
                       else -> {
                           inf.enableFingerPrintSwitch.isChecked=false
                       }
                   }
               }



           }

           inf.darkModeSwitch.setOnCheckedChangeListener { buttonView, isChecked ->
               if (isChecked) {
                   shared.edit().putString(shared_settings_mode_key, shared_settings_mode_dark).apply()
                   AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
               } else {
                   shared.edit().putString(shared_settings_mode_key, shared_settings_mode_light).apply()
                   AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
               }
           }

           inf.show_profile.setOnClickListener {
               findNavController().navigate(R.id.action_profileFragment_to_personalDetails, null,
                   navOptions {
                       anim {
                           enter = android.R.animator.fade_in
                           exit = android.R.animator.fade_out
                       }
                   })
           }
       }catch (e:Exception){
           Toast.makeText(requireContext(), e.message, Toast.LENGTH_LONG).show()
       }
        return inf
    }

    private fun showCurrencyDialog() {
        val view = LayoutInflater.from(requireActivity()).inflate(R.layout.show_currncy_dialog,null)
        val builder = AlertDialog.Builder(requireContext(), R.style.CustomAlertDialog).create()
        builder.setView(view)
        builder.setCanceledOnTouchOutside(false)
        view.listOfCurrency.setOnItemClickListener { parent, view, position, id ->
            shared.edit().putInt(currency_key,position).apply()
            Toast.makeText(requireContext(), resources.getString(R.string.toastSaved), Toast.LENGTH_SHORT).show()
            builder.dismiss()
        }
        view.listOfCurrency.adapter=ArrayAdapter(requireContext(),R.layout.dropmenu, arrayCurrency)
        view.btn_cancelCurrency.setOnClickListener {
            builder.dismiss()
        }

        builder.show()


    }

    private fun confirmBiometrics(file: File,inf: View,password: String?,question: String?,answer: String?) {

        executor = ContextCompat.getMainExecutor(requireContext())
        biometricPrompt = BiometricPrompt(requireActivity(), executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                shared.edit().clear().apply()
                if (file.exists()){
                    file.delete()
                }
                inf.enableFingerPrintSwitch.isChecked=false
                Toast.makeText(requireContext(), resources.getString(R.string.toastClearSettings), Toast.LENGTH_SHORT).show()
                refresh()
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                super.onAuthenticationError(errorCode, errString)
                if (password!=null&&question!=null&&answer!=null) {
                    resetSettings(password, question, answer, file, inf)
                }else{
                    Toast.makeText(requireContext(), resources.getString(R.string.thereisNopass), Toast.LENGTH_SHORT).show()
                }
            }

            override fun onAuthenticationFailed() {
                super.onAuthenticationFailed()
                Toast.makeText(requireContext(), resources.getString(R.string.toastError), Toast.LENGTH_SHORT).show()
            }
        })


            promptInfo = BiometricPrompt.PromptInfo.Builder()
                .setTitle(resources.getString(R.string.Biometricconfirmation))
                .setSubtitle(resources.getString(R.string.desforBiometric))
                .setNegativeButtonText(resources.getString(R.string.Useapasswordinstead))
                .build()
        biometricPrompt.authenticate(promptInfo)
    }

    private fun refresh() {
        val fragmentId = findNavController().currentDestination?.id
        findNavController().popBackStack(fragmentId!!,true)
        findNavController().navigate(fragmentId)

    }


    private fun confirmBiometricsForSwitch(inf: View,sharedPreferences: SharedPreferences) {

        executor = ContextCompat.getMainExecutor(requireContext())
        biometricPrompt = BiometricPrompt(requireActivity(), executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                sharedPreferences.edit().putString(
                    shared_settings_Biometrics_key,
                    shared_settings_Biometrics_disabled
                ).apply()
                inf.enableFingerPrintSwitch.isChecked=false
            }
            override fun onAuthenticationFailed() {
                super.onAuthenticationFailed()
                Toast.makeText(requireContext(), resources.getString(R.string.toastError), Toast.LENGTH_SHORT).show()
            }
        })


        promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle(resources.getString(R.string.Biometricconfirmation))
            .setSubtitle(resources.getString(R.string.desforBiometric))
            .setNegativeButtonText(resources.getString(R.string.btn_cancel))
            .build()
        biometricPrompt.authenticate(promptInfo)
    }

    private fun showPasswordDialog(password:String,question:String,answer:String) {

        val layoutInflater = LayoutInflater.from(requireActivity())
        val builder = AlertDialog.Builder(requireContext(), R.style.CustomAlertDialog).create()
        val view = layoutInflater.inflate(R.layout.dialog_password, null)
        builder.setView(view)
        builder.setCanceledOnTouchOutside(false)

        view.btn_done_password_dialog.setOnClickListener {
            val getpassword=view.et_SetPassword_dialog.text.toString().trim()
            if (getpassword.isNotEmpty()&&getpassword==password){
                builder.dismiss()
                findNavController().navigate(R.id.action_profileFragment_to_passwordFragment, null,
                    navOptions {
                        anim {
                            enter = android.R.animator.fade_in
                            exit = android.R.animator.fade_out
                        }
                    })
            }else{
                Toast.makeText(requireContext(), resources.getString(R.string.toastincorrectPass), Toast.LENGTH_SHORT).show()
            }
        }
        view.btn_cancel_password_dialog.setOnClickListener {
            builder.dismiss()
        }
        view.tv_forget_password_dialog_clicked.setOnClickListener {
            goneSetPassword(view)
            showForgetPassword(view)
            view.tv_forget_password_Q_dialog.text = question
        }
            view.iv_backFromForgetPassword_dilaog.setOnClickListener {
                goneForgetPassword(view)
                showSetPassword(view)
            }
            view.btn_done_forget_password_dialog.setOnClickListener {
                val getanswer=view.et_ForgetPassword_dialog.text.toString().trim()
                if (getanswer==answer){
                    builder.dismiss()
                    findNavController().navigate(R.id.action_profileFragment_to_passwordFragment, null,
                        navOptions {
                            anim {
                                enter = android.R.animator.fade_in
                                exit = android.R.animator.fade_out
                            }
                        })
                }else{
                    Toast.makeText(requireContext(), resources.getString(R.string.toastWrong), Toast.LENGTH_SHORT).show()
                }
            }

            view.btn_cancel_forget_password_dialog.setOnClickListener {
                builder.dismiss()
            }



        builder.show()
    }

    private fun showForgetPassword(view: View) {
        view.iv_backFromForgetPassword_dilaog.visibility=View.VISIBLE
        view.et_ForgetPassword_dialog.visibility=View.VISIBLE
        view.tv_forget_password_dialog.visibility=View.VISIBLE
        view.tv_forget_password_Q_dialog.visibility=View.VISIBLE
        view.LinearLayout_forgetPassword_dialog.visibility=View.VISIBLE
    }
    private fun goneForgetPassword(view: View) {
        view.iv_backFromForgetPassword_dilaog.visibility=View.GONE
        view.et_ForgetPassword_dialog.visibility=View.GONE
        view.tv_forget_password_dialog.visibility=View.GONE
        view.tv_forget_password_Q_dialog.visibility=View.GONE
        view.LinearLayout_forgetPassword_dialog.visibility=View.GONE
    }
    private fun goneSetPassword(view:View) {
        view.btn_cancel_password_dialog.visibility=View.GONE
        view.tv_forget_password_dialog_clicked.visibility=View.GONE
        view.btn_done_password_dialog.visibility=View.GONE
        view.tv_password_dialog.visibility=View.GONE
        view.et_SetPassword_dialog.visibility=View.GONE
        view.LinearLayout_password_dialog.visibility=View.GONE
    }
    private fun showSetPassword(view:View) {
        view.btn_cancel_password_dialog.visibility=View.VISIBLE
        view.tv_forget_password_dialog_clicked.visibility=View.VISIBLE
        view.btn_done_password_dialog.visibility=View.VISIBLE
        view.tv_password_dialog.visibility=View.VISIBLE
        view.et_SetPassword_dialog.visibility=View.VISIBLE
        view.LinearLayout_password_dialog.visibility=View.VISIBLE
    }

   private fun resetSettings(password:String,question:String,answer:String,file:File,inf:View){

           val layoutInflater = LayoutInflater.from(requireActivity())
           val builder = AlertDialog.Builder(requireContext(), R.style.CustomAlertDialog).create()
           val view = layoutInflater.inflate(R.layout.dialog_password, null)
           builder.setView(view)
           builder.setCanceledOnTouchOutside(false)

           view.btn_done_password_dialog.setOnClickListener {
               val getpassword=view.et_SetPassword_dialog.text.toString().trim()
               if (getpassword.isNotEmpty()&&getpassword==password){
                   builder.dismiss()
                   shared.edit().clear().apply()
                   if (file.exists()){
                       file.delete()
                   }
                   inf.enableFingerPrintSwitch.isChecked=false
                   Toast.makeText(requireContext(), resources.getString(R.string.toastClearSettings), Toast.LENGTH_SHORT).show()
                   refresh()
               }else{
                   Toast.makeText(requireContext(), resources.getString(R.string.toastincorrectPass), Toast.LENGTH_SHORT).show()
               }
           }
           view.btn_cancel_password_dialog.setOnClickListener {
               builder.dismiss()
           }
           view.tv_forget_password_dialog_clicked.setOnClickListener {
               goneSetPassword(view)
               showForgetPassword(view)
               view.tv_forget_password_Q_dialog.text = question
           }
           view.iv_backFromForgetPassword_dilaog.setOnClickListener {
               goneForgetPassword(view)
               showSetPassword(view)
           }
           view.btn_done_forget_password_dialog.setOnClickListener {
               val getanswer=view.et_ForgetPassword_dialog.text.toString().trim()
               if (getanswer==answer){
                   builder.dismiss()
                   shared.edit().clear().apply()
                   if (file.exists()){
                       file.delete()
                   }
                   inf.enableFingerPrintSwitch.isChecked=false
                   Toast.makeText(requireContext(), resources.getString(R.string.toastClearSettings), Toast.LENGTH_SHORT).show()
                   refresh()
               }else{
                   Toast.makeText(requireContext(), resources.getString(R.string.toastError), Toast.LENGTH_SHORT).show()
               }
           }

           view.btn_cancel_forget_password_dialog.setOnClickListener {
               builder.dismiss()
           }



           builder.show()
       }


}

